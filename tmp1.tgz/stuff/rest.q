//Rest server to serve data to altair viz - relative URL is the function name. For example /f calls f` 

\l qsrc/stat.q
\p 5001

yt: 2750 + 2*norm 1000;
resid: norm 1000;
covar: xexp[1 + 0.2*norm 1000;2];

f:{[x] s:dev yt;m: avg yt;: .h.hy[`json] .j.j flip (`time`y`b5`b95`pchg`resid`covar)!(til count yt;yt;m + xn[0.05]*s;m + xn[0.95]*s;0f,1 _ deltas yt;resid;covar);};

.z.ph:{:value x[0],"`";};
.z.pp:{:value (first "?" vs x[0]),"`";}
