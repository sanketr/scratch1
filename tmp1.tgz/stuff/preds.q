\l qsrc/stat.q
\l qsrc/kalman.q

//Set random seed
system "S ",string floor (`long$.z.p)%1e9;

//Factorial
fac: {[n] prd 1 + til n}
//n C k combinations
nck: {[n;k] fac[n]%fac[n-k]*fac[k]}
//Binomial trials - given p and n trials, prob of k successes
binomp:{[p;n;k] nck[n;k]*xexp[p;k]*xexp[1-p;n-k]}

//Binomial trials, p, n and at least r successes - sum up probability of
// all outcomes with r until n successes
binomt:{[p;n;r]  sum r _ binomp[p;n;] each til n+1} 

//Sharpe calculations
sr:{[p;n] xexp[n;0.5]*(-1 + 2*p)%2*sqrt p*(1-p) }
srf:{[p;n;f] xexp[n;0.5]*(-1 + 2*p)%sqrt ((1 - p)*p*4) + 0.31*xexp[f;2]}

/Gambler's ruin notes: http://www.columbia.edu/~ks20/FE-Notes/4700-07-Notes-GR.pdf
/Gambler's ruin probability - i is starting capital
rp:{[p;i] xexp[(1-p)%p;i]}

/Rounding to digit n
round:{[n;x] xexp[10;neg n]*floor (x*xexp[10;n]) + 0.5}
/Price to nearest ticksize specified by tick
tickprice:{[tick;p] tick*round[0;p%tick]}
//Bet sizing of positions given probability vector and target size
betsizes:{[p;s] `int$round[0;] s%(count p)*p}

//Bet averaging - return list of filled price and filled size given list of probabilities p, prices
//TODO - supply betsizes and limit prices depending on buy/sell
/ a:avg each flip {[n;m] {[x;i] avg x where i}'[ps[n];ps[n] > pmeans[n] - m*sqrt preds[n]]}'[til 5;1 1 1.2 1.4 1.4]
/ b:{[x;i] $[null x;first ps[0][i+1];x] }'[a;til count a]; {(avg x)%dev x} avg each 500 cut b - lows

//TODO: Input: prob p, pmean, pred, prices, actual mean, sign. Return: price, size, difference of vwap vs actual mean
betaveraging:{[p;prices;sign]
    prbs: $[sign=`sell;1-p;p]; //In case of sell, lowest price is highest probability
    bs: betsizes[prbs;100]%100;
    limitprs: xn each p; //Calculate limit prices for each bet size
    idx:  limitprs bin prices; //Binary search - in case of sell, from lowest to highest price => we take i. In case of buy, from highest to lowest => we drop lowest i
    :flip (`price`size)!flip {[b;p;takefn;i]  (sum takefn[i+1;b]*takefn[i+1;p];sum takefn[i+1;b])}[bs;limitprs;$[sign=`sell;#;_];] each idx;
  }

//TODO
//z - generate observations tagged with keys, given initial price and price variance
//h,covmat,cormat,hbar,m,mbar,hbar,rbar,q,cq,linv
//Generate pred covar, measure covars, kalman gains and cov pred error in steady state given q,hbar,mbar,rbar
//Generate measure means, pair with measure covars given z,linv,hbar,k - needed for backtesting
//Check for accuracy of predictions - validation function
// Backtesting - yt, up or down relative to start,%age of volume cap,pmeans,pdevs

//Get q,h,m,r,covmat,linv given ys (measurements e.g. highs) and xs (observations e.g. opens,highs5)
calcKNoiseParams:{[ys;xs]
    //Calculate for ys
    //Covariance matrix for measurements
    h: avg each flip xs%ys;
    covmat: cvm flip {[x;y;z] (y-x*z)}[;;h]'[ys;xs];
    cormat: crm flip {[x;y;z] (y-x*z)}[;;h]'[ys;xs];
    
    // Measurement noise calculation
    //Be careful - order of subtraction is reversed here because of process noise
    m1: cov[ys - prev ys;] each  flip {y-x*z}[;;h]'[ys;xs]; 
    m1a: raze flip mmu[inv first ldl covmat; flip enlist m1];
    h1: raze flip mmu[inv first ldl covmat; flip enlist h];
    r1: {x y}'[last ldl covmat ;til count covmat];
    linv: {[a;b;c] raze (a[b] til 1 + b),(c-b+1)#0f}[inv first ldl covmat;;count covmat] each til count covmat;
    q: var ys - prev ys;
    :(`q`hbar`mbar`rbar`covmat`linv)!(q;h1;m1a;r1;covmat;linv)
  }

//input q,hbar,rbar,mbar,covmat,linv - get preds,k,cprederr
calcKPredParams:{[noiseparams;ys;xs]
    q: noiseparams`q; h1:noiseparams`hbar;m1a:noiseparams`mbar;r1:noiseparams`rbar; linv:noiseparams`linv;
    //Calculate prediction deviation with steady state covariance - show in bps
    0N!"Uncertainty for ys in bps - open, end 1,end 2,end 3,end 4,end 5";
    0N!(1e4%2750)*sqrt preds: last hpreds: calcPredCov[q;h1;m1a;r1];
    ck0: first hpreds; //Steady state measurement covariance for initial measurement
    params1: {(`k`cprederr)!(last each x;last each (-1_) each x)}(ck0;0f;0f) covfusion \ {[x;y;z](x;y;z)}'[h1;m1a;r1];
    :(`preds`k`cprederr)!(preds;params1`k;params1`cprederr);
  }
    
//Take k,preds, hbar,linv,xs - get pmeans and residuals
//TODO: pair pmeans with preds and xn prob for betaveraging
predict:{[kalmanparams;noiseparams;xs;ys]
    linv: noiseparams`linv; hbar:noiseparams`hbar;
    kg: kalmanparams`k; preds: kalmanparams`preds; cprederr: kalmanparams`cprederr;
    //Observations z now adjusted by LDL, to diagonalize noise
    zbar: mmu[linv;] each xs;
    initmean: first ys; //We use this for initial input of mean to kalman filter
    // Let us check the hit ratios
    /Predict the means for each of the six (including the one after fifth) intervals - we are interested in only first 5
    pmeans: (raze (1#1_) each res: (initmean;(count first zbar)#0f;(count first zbar)#0f) {[init;z;h;k] vals:(0;init[0]) {[x;y] newmean[y[0];y[1];y[2];x[1]]}\ {(x;y;z)}'[z;h;k]; :(last last vals;last each vals;first each vals)}[;;hbar;kg] \ zbar); //Feed hbar, kalman gain and adjusted observations to calculate predicted means given the observations
    resids: raze (1#2_) each res;
    :(`pmeans`resids)!(pmeans;resids)}

//Diagnostics tests - take pmeans,preds,ys,allys - return pdf, volume, prob of hit for each interval
diagnostics:{[kalmanparams;kalmanpreds;ys;allys;side]
    preds: kalmanparams`preds; cprederr: kalmanparams`cprederr;
    pmeans: kalmanpreds`pmeans;
    //Check pdf of predicted mean and covariance vs actual mean
    show "Probability of miss +- 1 sigma: "," " sv string {(count x  where (abs x) > y)%count x}'[flip pmeans - ys;sqrt preds];
    //Check pdf of residuals
    show "Residuals +- 1 sigma: ", " " sv string {(count x  where (abs x) > y)%count x}'[flip kalmanpreds`resids;sqrt cprederr];
    show "Residual Variance/cprederr: ", " " sv string { (avg xexp[x;2])% y}'[flip kalmanpreds`resids;cprederr];
    //Calculate number of samples per interval = Number of samples/Number of intervals
    nsamples: (count allys)%count pmeans;
    //Calculate number of subintervals per interval
    nsubint: `int$-1 + count flip pmeans;  
    //number of samples per subinterval 
    nsamplesubs: `int$nsamples%nsubint;
    /Prices for each of the intervals - each price is for one unit
    ps: flip (nsubint cut nsamplesubs cut allys);
    nsigmas: raze ((floor nsubint*0.5)#1f), xexp[1.2f;1 + til nsubint - floor nsubint*0.5];
    show update nsigmas:nsigmas from {(`volume`prob)!(round[0;] avg x where x > 0;round[2;] (count x where x > 0)%count x)} each {[fn;ps;pmeans;preds;n;x]  {count where x} each  fn[ps[n];pmeans[n];x*sqrt preds[n]]}[$[side=`sell;{ x > y - z};{x < y + z}];ps;flip pmeans;preds;;]'[til nsubint;nsigmas]; //Calculate hits for each subinterval given prices for that subinterval, predicted mean and muliple of sigmas
  }

/
//Highs
nhparams: calcKNoiseParams[highs;opens,'highs5];
khparams: calcKPredParams[nhparams;highs;opens,'highs5];
khpreds: predict[khparams;nhparams;opens,'highs5;highs];
diagnostics[khparams;khpreds;highs;ys;`sell];

//Lows
nlparams: calcKNoiseParams[lows;opens,'lows5];
klparams: calcKPredParams[nlparams;lows;opens,'lows5];
klpreds: predict[klparams;nlparams;opens,'lows5;lows];
diagnostics[klparams;klpreds;lows;ys;`buy]

//Testing of bets
hidx: raze where each highs5=highs;
lidx: raze where each lows5=lows;
idx: { x bin y}'[(first pmeans)  +\: (sqrt first preds)*xn each 0.1 0.5 0.85;10000 cut ys];
a: {i:1 + max y; ((i#z);(i#x)) }[;;0.39 0.67 3.33]'[(first pmeans)  +\: (sqrt first preds)*xn each 0.1 0.5 0.85;{ distinct x} each idx];
r: { (sum x[0];sum x[0]*x[2] - x[1])} each a,'highs;
avg  ((last  each r)%(first each r)) where (hidx=0) and not (first each r)=0
count each  group  asc hidx where not (first each  r)=0
(count each  group  asc hidx where not (first each  r)=0)%count  each group  asc hidx
