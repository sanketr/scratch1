a:()!();
a1:()!();
a2:()!();
aIdx:();
highs5:();
lows5:();
opens:();
chunkSize: 480;
nSamples: 2000;

\l db
\P 10

fn: {[dts;idxs]
    a:: (uj/) {[x;y] :y#select from trade where date=x,sym=`XBTUSD;}'[dts;idxs];
    update dprice:0.0e from `a where i=0; //Mark first price change as 0 as well

    // Emit 1b as last element on price change
    csize: {[x;y;z] $[y=0.0;(x[0]+z[0];z[1];0b);(z[0];z[1];1b)]}\[(0i;exec first price from a;0b);exec dprice from a;(exec size from a),'exec price from a];
    a:: (a,' flip (`csize`change)!(csize[;0];csize[;2]));
    update pprice:prev price, psize:prev csize,pside:prev side from `a;

    //Get prev price and cumulate size where change = 1
    a1:: select date,time,price:pprice, size:psize, side:pside, idx:i from a where change=1;

    //Get carryover of chunks in excess of chunkSize 
    carry: `real$ ({ (x mod chunkSize) + y }\) exec size from a1;

    update chunked:carry - leftover from update leftover: `real$carry mod chunkSize from update carry:carry from `a1;

    update pleftover:prev leftover from `a1;
    update pleftover:0e from `a1 where i = 0;

    //Calculate vwap now - do vwap of size in current period with leftover of previous price period
    vwap: ({[x;y;z] z wavg (y;x)})\[0; exec price from a1;flip exec (size;pleftover) from a1];

    //Set actual price
    update pcostbasis:0e^prev costbasis from update costbasis:vwap from `a1;

    //Cut up prices in chunks of chunkSize now - divide each chunked size by chunkSize, and repeat prices that many times
    a2:: nSamples cut raze  {x#y} '[`int$exec chunked%chunkSize from a1;exec costbasis from a1] ;

    //Calculate highs/lows/opens
    highs5:: max each a2;
    lows5::  min each a2;
    opens:: first each a2;

    //Indices in trades, for each entry in a2 - that way, we can track trade entries corresponding to an event
    aIdx:: {(first x;last x)} each nSamples cut raze {x#y} '[`int$exec chunked%chunkSize from a1;exec idx from a1] ;
    //Save a copy of data for haskell code to run on - get output in out.log with same chunkSize and nSamples settings, and call cmpResults function
    `:/Users/sanket/scripts/code/startup/bitmex/datafeeds/a1.json 0: enlist .j.j select timestamp:`timestamp$timestamp,symbol:sym,side,size,price from a;

  }

saveFn:{[dts] 
  `:../trade.json 0: .j.j each 1024 cut select timestamp:`timestamp$timestamp,symbol:sym,side,size,price from trade where date within dts; 
  }

//Call this after calling fn
cmpResults:{
  //Read haskell log to read back opens,lows5,highs5
  tmp1: ("E"$) each ("," vs) each read0 `:/Users/sanket/scripts/code/startup/bitmex/datafeeds/out.log;
  0N!"Count of kdb periods and haskell periods: ", (string count opens), " | ", string count tmp1;
  0N!1 - min each flip ((min ((count opens);(count tmp1)))#(opens,'lows5,'highs5))%((min ((count opens);(count tmp1)))#tmp1);
  0N!max each flip ((min ((count opens);(count tmp1)))#(opens,'lows5,'highs5))%((min ((count opens);(count tmp1)))#tmp1);
  }
