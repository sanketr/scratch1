\l qsrc/test.q
\l qsrc/t1.q
\l qsrc/bet.q

// Function to solve fills - we set current fill proportional to current probability 

//Bet fold helper function - takes prev fill, current probability, cumulative probability including current period, target across all periods
//betfh:{[pfill;curprob;cumprob;target] fillt: (target*cumprob) - pfill; }

//Encode opl0 as negative distance so that if h0 < l0, idx of l0 is generally less - so, negative value will be more
opl0: neg hli0[;1]; oph0: neg hli0[;0];

//Function to get cumulative probability given (side;period i; open_h_i > open_l_i)
// Return cum prob until period i and current probability for period i
getcumprob:{[inp] 
          //Get the dictionary entry first - exception if wrong input
          d:$[`hidx = first inp;dhprobs1 1 _ inp;`lidx = first inp;dlprobs1 1 _ inp;'wrongInput]; 
          //Sum all of probability til (period + 1), and get period probability
          :(0f^sum d til 1 + inp[1];0f^ d inp[1]);   
          }

// TODO - get fills (vectorized for now, scan later), target
// input (`hidx;0;1) and filter function
getvfills:{[inp;filter] :{[x;i] x[;0][i]}[;inp[1]] each $[`hidx=inp[0];fpsh;`lidx=inp[0];fpsl;'wrongInput] filter (getidx 1 _ inp);}

//For now, do simple assumption that fills average to 70 when corresponding index is hit (i.e., hidx or lidx = i) - this will allow us
// to do some simple weighting for now

//Get fills for each side, and cum probability - target * cum probability - unhedged fills

getfillsh:{[side;sigma;i;pidx;frac;target] 
  r:side[sigma][;][i]; //get both prices and sizes
  ps: r[;0][;pidx] ; //Get prices for period
  fls: min(target;frac*r[;1][;pidx]);
  :(ps;fls)
  }

//Input dictionary: (`side`pidx`sigmas`targets`frac`i)
// `side: `buy or `sell
getfills:{[d] 
  side:$[`sell = d`side;ah;`buy = d`side;al;'wrongInput];
  //We get cost basis and fills, one row of entries over index per sigma - flip to get index in rows and sigma as columns
  r: getfillsh[side; ;d`i;d`pidx;d`frac;]'[d`sigmas;d`targets];
  //gather prices by indices over sigmas as columns
  fls: flip r[;1];
  ps: flip r[;0];
  //Return cost basis and total size
  :{ (sum x;x wavg y)}'[fls;ps];
  }

//Bet sizing for current period
// `pfill`cumprob`prob`target - prev fill, cumulative probability until current period, current period probability, target
// Do a floor of 0 in case too much fill has already happened, so we don't do negative fills
betfill:{[d] : max(0; ((d`target)*((d`cumprob) + (d`prob))) - (d`pfill))}

//Estimated fill needed for hedging - can refactor later to improve pnl
efill:{[d] (d`pfill) + (((d`target) - (d`pfill))*(1 - d`cumprob))}

//Get estimated highs5 and lows5 errors for conditions
geterrs:{flip (`period`lerrs`herrs)!(til 5;avg each flip lerrs x;avg each flip herrs x)}

////// Generate tmp4
//tmp4:([] iperms:first each iperms; n:{count (inter/) getidx each last x} each iperms);
//tmp4[`betsize]: {sum getdiag dhprobs1 last x} each iperms;
//bets: {getdiag dhprobs1 last x} each iperms;

//errs: {[inp] avg {[wts;x] (highs x) - {[wts;x] wts wavg x[;1]}[wts;] each fpsh x}[getdiag dhprobs1 last inp; (inter/) getidx each last inp]} each iperms;
//tmp4[`betsize]: sum each bets;
//tmp4[`errs]: errs;
//delete bets,errs from `.;
