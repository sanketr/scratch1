\c 25 90
\P 5

//Calculate high/low fills, prices centered around 1,0.75,0.75,0.5,0.25 sigmas
getVolumeOrPrice: {[i;side;sigma;idx] side[sigma][;i][;idx]}
getVolume:getVolumeOrPrice[1];
getPrice:getVolumeOrPrice[0];
getTVolume:{[side;sigma;idx;frac;target] min(;target) frac*getVolume[side;sigma;idx]}

//Get fills and prices given fill targets, and fractional limit on fills
getfps: {[side;frac;idx;sigmas;targets] fillvs: flip getTVolume[side;;idx;frac;]'[sigmas;targets];:flip (fillvs;flip getPrice[side;;idx]'[sigmas]);}

//Get fills and prices given indices, and sigmas for period p 
// Return dictionary keyed on sigmas, each sigma containing tuple (size,price) for indices i
getfpsi:{[params;i] 
    //For each sigma over i, pair up (size,price) for each entry
    flls: {[side;frac;p;i;sigma] vols: `int$frac*side[sigma][;1][;p] i; ps:  side[sigma][;0][;p] i; :vols,'ps }[$[`h=params`side;ah;`l=params`side;al;'errInvalidSide];params`frac;params`p;i] each params`sigmas; 
    :(params`sigmas)!flls;
   }

//Group summary - show total, and probability distribution
gs: {show each (sum x;"###";100*sums x%sum x;"###";100*x%sum x);}

//Sort dictionary on key
sdict:{[d] k: asc key d; :k!d k;}

//Get fills and prices for highs centered around 1e
// For each idx, calculate sigmas and bet sizes averaging to 100 conditional on hit

//betFracs:(til 5)!((0.75 1 1.25e;12 72 24);(0.25 0.5 0.75e;66 51 33);(-0.25 0 0.25 0.5 0.75e;72 60 36 24 18);(-0.5 -0.25 0 0.25 0.5 0.75e;76 53 40 33 24 20);(-1 -0.25 0 0.5e;242 120 132 102));
betFracs:(til 5)!((0.75 1 1.25e;12 45 24;0.8*0.33 0.56 0.89);(0.25 0.5 0.75e;16 31 46;0.8*0.3 0.5 0.7);(-0.25 0 0.25 0.5 0.75e;12 20 36 24 18;0.8*0.15 0.25 0.4 0.55 0.8);(-0.5 -0.25 0 0.25 0.5 0.75e;16 23 40 33 24 20;0.8*0.2 0.3 0.4 0.5 0.7 0.8);(-1 -0.25 0 0.75e;90 90 152 62;0.7*0.3 0.5 0.6 0.9)); //aggressive fills for period 1 - we also hit 1 sigma, and hit more on 1 sigma. We also hit less in period 0. We multiply actual probability of fills (3rd entry) by ~0.8 since this is what seems to happen in simulation for expected fills

//Bet fraction that targets fill size of 75 for each period - ~100 fill for the interval
betFracs75: {[x;f] (x[0];x[1]*f;x[2])}'[betFracs;1.57 1.5 1.6 1 0.4];
betFracs100: {[x;f] (x[0];x[1]*f;x[2])}'[betFracs75;5#1.4e];

//Calculate means for each period betting - we will subtract mean sigma to center bets for that period to calculate distance shift for bets
betMeans: tickprice[0.25e;] med each first each value betFracs;

//Get whether h0 or l0 gets hit first (min 1 sigma), in first period - (high idx;low idx)
hli0:{(first where (pmeans[0][x] - (max (1;(highBuoys`h0)[x])*sqrt preds[0])) <= ps[0][x]; first where (plmeans[0][x] + ((max (1;(lowBuoys`l0)[x]))*sqrt preds[0])) >= ps[0][x]) } each til 5000;

/ how much has accumulated so far, what fraction should it be of total, what is new normalized total, what is new betsize as fraction of normalized total

//Function to calculate bet sizes given first period bet and probs for all 5 periods
betcalc:{[firstbet;probs] firstfrac:firstbet; firstfrac, exec frac from  {[x;y] accumfrac:sum 0^y til 1 + x`i; curfrac:0^y x`i; normtotal:(x`cfrac)%accumfrac - curfrac; betfrac:curfrac*normtotal; update frac:betfrac from update cfrac:cfrac + betfrac, accum: accumfrac, total:normtotal, i:i + 1 from x}\[(`i`frac`cfrac`accum`total`max)!(1;firstfrac;firstfrac;firstfrac;0;3);probs]}

//Probabilities for conditions on tint - we start with condition for period 0, and take up to 4 (0,1,2,3) - cumulative conditions here
chprobs: {[conds] {x%sum x} each {?[`tint;x;`hidx;(count;`i)]} each {[x;conds] x#conds}[;conds] each 1 _ til 5}
// chprobs conditioned only on last event - we look at last event in period 0 through 4 - assumption is we guess it through buoy pings in current period
chprobsl: {[conds] {x%sum x} each {?[`tint;x;`hidx;(count;`i)]} each {[x;conds] enlist conds[x]}[;conds] each til 4}

//Low probablity - fine-grained starting from period 0
clprobs: {[conds]  {x%sum x} each {?[`tint;x;`lidx;(count;`i)]} each {[x;conds] x#conds}[;conds] each 1 _ til 5}
//Low prob conditioned on only last event
clprobsl:  {[conds] {x%sum x} each {?[`tint;x;`lidx;(count;`i)]} each {[x;conds] enlist conds[x]}[;conds] each til 4}

//Generate conditions for select query on tint - cut in a particular way so each cond is a list element instead of flattened
genconds:{fns:(>;<=); fnBuoys: raze {[x;fns] fns cross enlist x}[;fns]each { (`$("h",)x), `$ ("l",) x} each string each til 5; :{3 cut x} each {x[0] cross x[1] cross x[2] cross x[3]} 2 cut fnBuoys;}

//Get condition idx
getcidx: {?[`tint;x;();`i]}

//Generate annotation for condition of the form (fn;arg1;arg2)
genCondAnnotation:{`$" | " sv { " " sv string (x[1];x[0];x[2])} each x}; 

/q) obs: ((<;`h0;`l0);(<;`h1;`l1);(>;`h2;`l2);(<;`h3;`l3)) //One entry from genconds
/q) probs: {x%sum x} each {?[`t;x;`hidx;(count;`i)]} each { x#obs} each 1 _ til 5 //Handled by chprobs function above now
/q) getidx[obs] /indices that cover all consecutive observations

tmp1: raze {?[`tint;x;0b;`cond`n`hidx`lidx!(enlist enlist genCondAnnotation x;(count;`i);(avg;`hidx);(avg;`lidx))]} each genconds`;

//TODO - update betcalc to take first of probs, or may be just take all probs, no starting args
errtbl: flip (enlist `errs)! enlist {[i] conds:genconds`; (betcalc[$[i < 8;0.29;0.1];chprobs[conds[i]]]) wavg {[pidx;i] avg (highs i) - last each { (sum x[0];x[0] wavg x[1])} each getfps[ah;0.3;pidx;betFracs[pidx][0];betFracs[pidx][1]] i}[; getcidx[conds[i]]] each til 5} each til 16;

//Save a full table of errors by index - that way, we can look up error for any index
errftbl: `i xasc raze {[i;conds;errs] idx: getcidx conds[i];flip (`errs`i)!((count idx)#errs[i];idx)}[;genconds`;exec errs from errtbl] each til 16;

bsizetbl: flip (enlist `betsize)!enlist sum each { conds:genconds`; :{[i;conds]:betcalc[$[i < 8;0.29;0.1];chprobs[conds[i]]]}[;conds] each til 16}`;
bsizeftbl: `i xasc raze {[i;conds;betsize] idx: getcidx conds[i];flip (`betsize`i)!((count idx)#betsize[i];idx)}[;genconds`;exec betsize from bsizetbl] each til 16;

condftbl: `i xasc raze {[i;conds] idx: getcidx conds[i];flip (`cond`i)!((count idx)#i;idx)}[;genconds`] each til 16;

tmp1: tmp1 ,' errtbl ,' bsizetbl;
tmp2: tmp1 ,' delete cond from select nlerr: avg nlow - low, nherr: avg high - nhigh by cond from (tint,'condftbl);
update terrs:errs + reverse errs from `tmp2;

conds:genconds`; //Enumerate all conditions
//Calculate total errors and map to first 8 conditions
tmp3:`cond xcols update cond:conds i from flip (`n`errs)!{ ((8#x`n) + reverse -8#x`n; (8#x`errs) + reverse -8#x`errs)} exec errs,n from tmp2;

//In first period, some kind of guess on what we should bet on first - track which (high,low) 1 sigma buoy is hit first
hli0:{(first where (pmeans[0][x] - (max (1;(highBuoys`h0)[x])*sqrt preds[0])) <= ps[0][x]; first where (plmeans[0][x] + ((max (1;(lowBuoys`l0)[x]))*sqrt preds[0])) >= ps[0][x]) } each til 5000;

//Building block for continuous hedging calculator - use in fold
hedgecalc:{[tprob;hprob;target;tfill;hfill;hedgefrac;cap] tsize: target - tfill; hsize: ((tsize*tprob) + tfill - hfill)*hedgefrac%hprob;:(tsize;min(cap;hsize))} /Must hedge both high and low continuously

//Local high/low errors per period vs global - this helps us estimate whether to ask for more fills, or not
herrs: highs - highs5;  lerrs: lows5 - lows;

//Open to predicted means distances for current period as multiple of sigmas - oh*/ol*
{[x] value "oph",(string x),": {[x] neg tickprice[0.25;(opens5[;x] - pmeans[x])%sqrt preds[x]]}[",(string x),"]"} each til 5;
{[x] value "opl",(string x),": {[x] tickprice[0.25;(opens5[;x] - plmeans[x])%sqrt preds[x]]}[",(string x),"]"} each til 5;

//Highs5/Lows5 to predicted means distances for period i as multiple of sigmas - can use only in next period
{[x] value "hph",(string x),": {[x] neg tickprice[0.25;(highs5[;x] - pmeans[x])%sqrt preds[x]]}[",(string x),"]"} each til 5;
{[x] value "lpl",(string x),": {[x] tickprice[0.25;(lows5[;x] - plmeans[x])%sqrt preds[x]]}[",(string x),"]"} each til 5;

fpsh: flip { {(sum x[0];x[0] wavg x[1])} each getfps[ah;0.3;x;betFracs[x][0];betFracs[x][1]]} each til 5;
fpsl: flip { {(sum x[0];x[0] wavg x[1])} each getfps[al;0.3;x;betFracs[x][0];betFracs[x][1]]} each til 5;

/tmp4: flip update fpsh:fpsh, fpsl:fpsl, h:highs, nh:nhighs, l:lows, nl:nlows, hidx: hidx, lidx:lidx from condftbl;
tmp4: update errs:(min(betsize;lbetsize);abs hsize) wavg (terrs;terrs+herr) from update herr:?[hsize>0;nlerr;nherr] from update hsize:betsize - lbetsize from select n,terrs,betsize,lbetsize:reverse betsize,  nlerr,nherr from tmp2;

//Calculate l and high probs given arbitraty indices
clprobs1: {[idx] {100*x%sum x} {[idx]?[tint;enlist (in;`i;idx);`lidx;(count;`i)]}[idx]} ;
chprobs1: {[idx] {100*x%sum x} {[idx]?[tint;enlist (in;`i;idx);`hidx;(count;`i)]}[idx]};
