steadycovpredh:{[f;h;q;m;r] 
  shared1: (xexp[f;2]*r) + (xexp[h;2]*q) - (2*h*m) + r;
  //There can be case when shared2 is negative, e.g.args:  1 1 1.082418 -1.00746 0.7279091
  //shared2: sqrt max(0f; ((xexp[f;2]*r) + (xexp[h;2]*q) + (2*h*m) + r - (2*f*h*m) + 2*f*r )*((xexp[f;2]*r) + (xexp[h;2]*q) + (2*h*m) + r + (2*f*h*m) + 2*f*r));
  shared2: sqrt ((xexp[f;2]*r) + (xexp[h;2]*q) + (2*h*m) + r - (2*f*h*m) + 2*f*r )*((xexp[f;2]*r) + (xexp[h;2]*q) + (2*h*m) + r + (2*f*h*m) + 2*f*r);
  :((shared1 - shared2)%2*xexp[h;2];(shared1 + shared2)%2*xexp[h;2])} 

covmeasure:{[f;h;q;m;r;cpred] covpred:max cpred where cpred > 0; k:((covpred*h) + m)%((xexp[h;2]*covpred) + (2*m*h) + r); : (covpred - k*((h*covpred)+m))}

kalmangain:{[p;h;m;r] cprederr: r + (2*h*m) + xexp[h;2]*p; k:(m + p*h)%cprederr; :(k;cprederr)}

newmean:{[z;h;k;x] resid:z - h*x; :(resid; x + k*resid)}

covfusion:{[x;y] p:x[0]; h:y[0];m:y[1];r:y[2]; r1: kalmangain[p;h;m;r]; k:r1[0];cprederr:r1[1]; (p - k*(m + h*p);p;cprederr;k)} 

covfusionadj:{[x;y] p:x[0]; h:y[0];m:y[1];r:y[2];adj:y[3];r1: kalmangain[p;h;m;r]; k:r1[0]%adj;cprederr:adj*r1[1]; (p - k*(m + h*p);p;cprederr;k)}

calcPredCov: {[q;h;m;r] 
  //Calculate steady state covariance of first measurement - please note that f is set to 1 here for DARE equation
  ck0: max steadycovpredh[1;first h;q;first m;first r];
  /0N!"First ck0: ", string ck0;
  if[(null ck0) or ck0 < 0; 0N!"Can't proceed because of unstable steady state";'brk;];
  //Proceed only if stable steady state solution else 
  //Calculate steady state covariance after fusion
  ck0: q + first last (ck0;0;0;0) covfusion \ {(x;y;z)}'[h;m;r];
  /0N!"Second ck0: ", string ck0;
  //Output starting steady state covariance, and prediction covariance for each measurement
  :(ck0;first each (ck0;0;0;0) covfusion \ {(x;y;z)}'[h;m;r]);
  }
