
cwd: system "cd"; //Get current working directory - we will use it to locate other files for loading
reldir:$[0 = count cwd ss "qsrc";"qsrc/";""]; //get relative directory for locating library files

system "l ",reldir,"kalman.q";

//h for open/highs = 1 - (1/2)* spread/open price = (1/2)* 1.59 * sqrt cq % open
hopn:{[side;cq;open] 1 + $[side=`h;-1;1]* 0.5*1.595*xexp[cq;0.5]%open }
//h for rest i.e. highs/lows over highs5/lows5 = 1 - (sqrt cq)/((sqrt nprd)*open)
// nprd might be scaled,e.g., 5^0.7, to account for variance scaling due to human actions
hrst:{[side;cq;open;gamma;nprd] 1 + $[side=`h;-1;1]* xexp[cq%xexp[nprd;gamma];0.5]%open }

//Function to calculate h given price variance, price and number of observations
calcH:{[side;cq;price;gamma;n] : raze(hopn [side;cq;price];(n-1)#hrst[side;cq;price;gamma;n-1])}

//kalman filter noise parameter calculations
// - calculate q,h,m,r,linv - h and m are unadjusted, r is diagonal noise of ldl over covmat
calcMktNoiseParams:{[side;cq;nprd;means;obs]
  h: calcH[side;cq;first means;1e;count first obs];
  covmat: cvm flip {[x;y;z] (y-x*z)}[;;h]'[means;obs];
  // Measurement noise calculation
  //Be careful - order of subtraction is reversed here because of process noise
  m1: cov[means - prev means;] each  flip {y-x*z}[;;h]'[means;obs];
  r1: {x y}'[last ldl covmat ;til count covmat];
  q: var means - prev means;
  //linv is done that way below to guarantee 0s in upper diagonal
  linv: {[a;b;c] raze (a[b] til 1 + b),(c-b+1)#0f}[inv first ldl covmat;;count covmat] each til count covmat;
  :(`h`q`m`r`linv)!(h;q;m1;r1;linv);
  }

// - get pred sigmas, k, cprederr using covfusion - k and cprederr come from kalmangain helper
calcKParamsH:{[q;h;m;r;linv]
  // - adjust m and h using linv
  h1: raze flip mmu[linv;flip enlist h];
  m1: raze flip mmu[linv;flip enlist m];
  preds: last hpreds: calcPredCov[q;h1;m1;r];
  ck0: first hpreds; //Steady state measurement covariance for initial measurement
  params1: {(`k`cprederr)!(last each x;last each (-1_) each x)}(ck0;0f;0f) covfusion \ {[x;y;z](x;y;z)}'[h1;m1;r]; 
  :(`preds`k`cprederr)!(preds;params1`k;params1`cprederr);
  }

//Code to generate q,m,r,inv given cq values - h should be generated using equations
// q ~ 0.72*cq
// m ~ scale*m' where cq' is simulated reference for calculation, cq=scale*cq', m' is unadjusted noise
// r ~ scale*r'
// linv - constant
scaleMktNoiseParams:{[scale;cq;m;r] 
  q: 0.72*cq*scale;
  m1: scale*m;
  r1: scale*r;
  :(`q`m`r)!(q;m1;r1);
  }

//Get hbar (for high and low: hh/hl),linv,k,cprederr that we need for kalman newmean
//linv is needed to adjust observations z and get zbar
calcKParams:{[side;price;scale;openscale;gamma;d]
    q:scale*d`q;
    m:scale*d`m;
    r:scale*d`r;
    //Scale cq by a parameter for now because of too much noise - otherwise probability barriers might be breached because of too high h for open using default relationship between q and cq
    hh: calcH[`h;q*openscale;price;gamma;6]; //Note h is for 6 observations
    hl: calcH[`l;q*openscale;price;gamma;6];
    hh1: raze flip mmu[d`linv;flip enlist hh];
    hl1: raze flip mmu[d`linv;flip enlist hl];
    :update q:q, m:m, r:r, hh:hh1, hl:hl1, linv:d`linv from calcKParamsH[q;$[side=`l;hl;hh];m;r;d`linv];
  }

// - zbar - adjusted observations for opens + h5/l5 using linv
// - Calculate residual and mean using newmean
// - Adjustment for next interval using mean
\
z: opens,'highs5;
zbarh: mmu[linv;] each opens,'highs5;
zbarl:  mmu[linv;] each opens,'lows5;

q){[env;x;z] newmean[z;env`h;env`k;x[1]]}[(`h`k)!(1e;1e);;]\[(0;2750f);2751 2750.5f]
1    2751  
-0.5 2750.5

q)//repeat above for each interval over 5 periods - feed z,h,k corresponding to that period
// {[env;z] newmeanh[getInitMean env;getParams env] \ z} \ obs / get initial mean and params for current interval, scan over observations for current interval. Do over observations, carry pair of env and observations may be where env is calculated given observations

//checklist:
// - mean correction might be applied at the beginning using actual high/low from previous interval, but might be better to scale up cprederr via Q and R, and do mean correction only for regime transition if any
// - Historical
// -- keep track of period variance scaling power - ~0.63 for now. Need for h
// -- keep track of percentile rank of next range given current range. Useful for Q adjustment
// -- keep track of cq scale, and parameter adjustments needed for cprederr scaling
// -- keep track of mu, sigma and lambdas for different trading environments
// -- | in case of divergence, two things to track and fix - H values too high or low (more residual error), Q values too low

