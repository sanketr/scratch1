//High low permutations by period - encodes (period i, open_h_i > open_l_i)
hlperms: (til 5) cross til 2; 

//Generate indices keyed by (oph_i > opl_i) flag
iperms: {(x;{(x;y)}'[1 _ til 5;x])} each {x cross x} (0;1) cross (0;1) ;

//Function to generate probability and indices given hlperms list and side (`hidx or `lidx)
genprobs: { i:string x[0];gt:x[1];side:y; idxstr:" where oph",i,$[gt=1;" > ";" <= "], "opl",i; :(eval parse"{x%sum x} count each group asc ",(string side) ,idxstr; eval parse idxstr)} 

//Generate dictionary of probabilities by (side;period i; open_h_i > open_l_i)
dhprobs1: hlperms!first each genprobs[;`hidx] each hlperms;
dlprobs1: hlperms!first each genprobs[;`lidx] each hlperms;

//Get indices for respective conditions above
didx1: hlperms!last each genprobs[;`hidx] each hlperms;
/didxl1: hlperms!last each genprobs[;`lidx] each hlperms;

getidx: {[inp] :(inter/) didx1 inp;}

//Version of getidx to get indices for successive periods - returns n indices for n periods. That way, we can trace the path after a period has elapsed to figure out where we are given the events that have already ocurred
getidx1:{[inp] { (inter/) y#x}[didx1 inp;] each 1 + til (count inp)}

//Calculate how capital will scale: starting with $20k, bet no more than half of the amount, 54% return daily on average
capitalScaling: {(x[0]+x[1];(x[0]+x[1])*0.5*0.35) }\[10;(20000;0)]; //First tuple - current bankroll: Add previous bankroll + winning. Second tuple - today's return given current bankroll: multiply bankroll by half for bet size limit, and calculate 60% return again

//Calculate average fill for period 2 - for iperms < 8, lows get filled usually. So, we calculate average fill for lows - we sum up everything until period 2 after which we stop flipping
//We could do something like E-M where we keep track of average fills (E) given hedging attempts (M - not really maximization but basically hedging given E - this in turn affects E again in next period due to unhedged fills)
avgfill: {x[;1] wavg x[;0]} {[i;p](sum 3#(dlprobs1 last iperms i) p;count getidx last iperms i)}[;2] each til 8; //Sum everything up to period 2 for first 8 on low fill - do wavg by count

//Estimated H/L index, count, hedge errors for current period (>= 1) and iperms - don't know if we need it
ehli:{[i;x ] `idx`cond xcols update idx:x, cond:first iperms x from (`hidx`lidx`n`nherr`nlerr`hl)!{(avg hidx x;avg lidx x;count x;avg (highs - nhighs) x; avg (nlows - lows) x; avg (highs - lows) x)} getidx i#last iperms x}; 

probsh:{{x%sum x} each {[idx;i] ((til 5)!(5#0i)), count each group asc idx i}[$[y=`h;hidx;lidx];] each getidx1 last iperms x};

//Return cum prob and current prob for periods 1-4 given perms index and side `h/`l - probs[5;`h]
probs: { { { (sum -1 _ x; last x)} y#x y - 2}[probsh[x;y]; ] each 2 + til 4};

// get hedge side given perms index and period 1-4
hedgeSide:{ r: last (last iperms x) (y-1); :$[r=0;`h;`l]; };

//Bet errors should be same for both sides wrt local high/low. Let us just take high error here
localBetErrs:{avg (highs5[;x] - last each fpsh[;x])} each til 5;

getBetErrsH:{[idx] 
  hmiss: (avg each flip (highs - highs5) idx) + localBetErrs;
  lmiss: (avg each flip (neg lows - lows5) idx) + localBetErrs;
  hfill: {[idx;i] avg (highs - fpsh[;i][;1]) idx}[idx;] each til 5;
  lfill: {[idx;i] avg (neg lows - fpsl[;i][;1]) idx}[idx;] each til 5;
  :(`hm`hf`lm`lf)!(hmiss;hfill;lmiss;lfill)}

getBetErrs:{[idx] :getBetErrsH[getidx last iperms idx];}

//Price table of highs with prices and max of 30% volume - we set target to infinity to get that value
// Each period has pair of volumes and prices
getPTblh: {[side;betfracs] raze flip {[betfracs;side;x] getfps[side;0.3;x;betfracs[x][0];(count betfracs[x][0])#0we]}[betfracs;side;] each til 5}

getPTbl:{[hdata;ldata;betfracs]
    prtbl: `idx`p xcols update idx:floor i%5,  p:i mod 5 from ( flip (`hmxsize`hprice)! flip getPTblh[;betfracs] hdata) ,'  flip (`lmxsize`lprice)! flip getPTblh[;betfracs] ldata;
    // Map each index to respective iperms condition number. Key is index, value is condition number
  conddict: raze {[i] xs: getidx last iperms i; xs!(count xs)#i} each til 16; 
  prtbl: `idx`p`ci xcols update ci:conddict each idx from prtbl;
  :prtbl;
  }
//Idx as primary index, p as period number, period bets for both sides with max volume available for each bet
prtbl: getPTbl[ah;al;betFracs];

//Generate condition table keyed on ci, side and p, with cprob,cumprob,cond (oph_i > opl_i) for each side - we will join with prtbl
getCondTbl:{[probs]
  //First generate tables for each side, append together
  t:  `ci`side`p xkey update cond: {(last iperms x)[;1] y-1}'[ci;p] from raze {[probs;i;side] `ci`side`p xcols update p:i+1 from {[probs;cond;side] update ci:cond, side:side from { (`cumprob`cprob)!(sum y # x ; x y)}'[probs[cond;side];1 _ til 5]}[probs;i;side]}[probs;;]'[raze (til 16;til 16);raze (16#`l;16#`h)];
  //Now do side-ways join of each side after splitting the table in two, and renaming the columns by side
  :(delete side,ci,p from `cumprobl`cprobl xcol `cumprob`cprob xcols 0!select from t where side=`l),' (`ci`p xkey delete side from `cumprobh`cprobh xcol `cumprob`cprob xcols 0!select from t where side=`h);
 }

//Get table with probability and conditions filled in
getTblPc:{[betfracs] 
  //Create table with probabilities and conditions, update with betfill best price and best size for each side - we already have calculated 30% capping on fill volume
  tpc1: update hidx:hidx idx, lidx:lidx idx, h:highs idx, nh: nhighs idx, l:lows idx, nl: nlows idx from `cond xcols getPTbl[ah;al;betfracs] lj  getCondTbl[probsh];
  tpc1: update bblprice:{x wavg y}'[bblsize;lprice], bbhprice:{x wavg y}'[bbhsize;hprice] from update bblsize: {[betfracs;x;y] (1.0*betfracs[y][1]) & x}[betfracs;;]'[lmxsize;p], bbhsize: {[betfracs;x;y] (1.0*betfracs[y][1]) & x}[betfracs;;]'[hmxsize;p] from tpc1;
 :update lfills:sum (0 < sum each bblsize), hfills:sum (0 < sum each bbhsize) by idx from tpc1 where p > 0; //turn on fill indicator for each side for p > 0. This lets us track probability of at least one fill for each side
 }

tpc1: getTblPc[betFracs100];

//Function to calculate realized fills by condition index, period p (1-4) and flag (1/0b)
getRealizedFills:{[p1;fl] eval parse "`ci`p xkey update p:",(string p1),", flag:",(string fl)," from update rhsz:fhsz%n wavg fhsz, rlsz:flsz%n wavg flsz from select fh:(sum not null bbhprice)%count i, fl:(sum not null bblprice)%count i,fhsz: avg sum each bbhsize, flsz:avg sum each bblsize,avg hidx, avg lidx, n:count i by ci from tpc1 where p = ",(string p1),", oph",(string p1),$[fl=0b;">";"<="],"opl",(string p1)}
//Realize fill dict keyed on ci and p - don't need flag
rfdict: `p`ci xasc (uj/) getRealizedFills'[first flip (1 + til 4) cross (0b;1b);last flip (1 + til 4) cross (0b;1b)];

//Function to calculate bet fill sigmas for aggressive fills
fillSigmas:{[betsigmas;osigma;i] 
  //Calculate distance of new mean
  newmean: osigma + ((1 2 3 4)!(-0.25e;-0.5e;-0.75e;-0.75e)) i; 
  //Calculate distance of bet median from new mean
  dist: tickprice[0.25e;med betsigmas] - newmean;
  //Return new bet sigmas centered around new mean
  betsigmas - dist};

/ How to generate input - bet condition number of 0, avg Fill Size of a, and til 4 for last 4 periods
genInp: {[x;a]  {[idx;i;a] (`idx`hedgeSide`avgFillSize`hprobs`lprobs)!(i+1;hedgeSide[idx;i+1];a;probsh[idx;`h] i;probsh[idx;`l] i)}[x;;a] each til 4}
f: {[t] a1: update size1:min(hsize;lsize), size2:hsize - lsize from t; :first exec (n*max(hsize;lsize)) wavg terr1 from update terr1:(size1;abs size2) wavg (terr;terr+nerr) from select  n, terr, hsize,lsize, nherr, nlerr, size1, size2, nerr:?[size2>0;nlerr;nherr] from a1}
g: {[t] a1: update size1:min(hsize;lsize), size2:hsize - lsize from t; avgerr: first exec avg(lerr;herr) from select herr:n wavg herr, lerr: n wavg lerr from a1; update terr1:(size1;abs size2) wavg (terr;?[hsize > lsize;herr;lerr] + avgerr +nerr) from select  n, hidx,lidx, terr, hsize,lsize, nherr, nlerr, size1, size2, nerr:?[size2>0;nlerr;nherr],herr,lerr from a1}

//select from (`idx`n`terr1 xcols update idx:i from (g[;1.5e] { (update idx:i, n:{count getidx last iperms x} each i, terr:herr+lerr from {[i;x] {[x;y] (`herr`lerr`hsize`lsize)!((x`hf) wavg y`hf;(x`lf) wavg y`lf;sum x`hf;sum x`lf)  }[ibetcalc/[(`hf`lf)!(enlist x[0];enlist x[1]);genInp[i;0.14e]];getBetErrs[i]]}[;x] each til 16),'ehli[4;] each til 16}[(0.1e;0e)]) til 16) where i within (0;15)

// Iterative fill/hedge bet calculations
// inputs - hedgeSide, avgFillSize, h/l - cum prob (upto prev prob), prev prob, current prob
// Output - weights by sides for each period
// init is same shape as output. Start with initial weight in period 0 such as (hf`lf)!.... 
ibetcalc:{[missfill;initscale;init;inp] 
 / inp dict: (`idx`hedgeSide`avgFillSize`hprobs`lprobs) 
 / Set fill side key as flip of inp`hedgeSide 
 fside: $[`h=inp`hedgeSide;`l;`h];
 sideKeys:  (`h`l)!(`hf`hwt`hprob;`lf`lwt`lprob);
 / fill side dict keys
 fks: sideKeys fside;

 hside: inp`hedgeSide;
 hks: sideKeys hside;
 /Calculate probs for h and l sides
 probs: (`h`l)!{[x;y] (`probl`cumprob`pprob`cprob)!(value y _ x;sum y#x;x y-1;x y)}[ ;inp`idx] each (inp`hprobs;inp`lprobs); 
 r:()!();
 //For fill side, set current fill proportional to prob - set scaling of first bet to initscale (min for now), i.e., we assume that subsequent bet sizes are that multiple of p=0 bet. In case of no fill in p=0, we assume a missfill
 fillwtp:(first max (missfill;initscale*first init first fks);`real$((probs fside)`cprob));
 r[fks]: enlist each raze (`real$ $[`fside=`l;1;1]*prd fillwtp;fillwtp); //TODO - use the skew logic to rebalance the sides. For now, set to unskewed
 //For hedge side, calculate current fill given avgfill. Floor at 0 instead of negative
 //Set hedge weight to 0 if price is provided in input, and is null
 //hdgwt1: `real$ (max(0;(inp`avgFillSize) - sum raze init first hks)); //default hedge weight calculation - use if price exists
 hdgwt1: `real$ inp`avgFillSize; //default hedge weight calculation - use if price exists
 hdgwt: $[`price in key inp; $[null inp`price;0e;hdgwt1]; hdgwt1];
 /hdgwtp:(hdgwt;`real$((probs hside)`cprob)%$[(inp`idx) < 4;1;(1 - (probs hside)`cumprob)]);
 hdgwtp:(hdgwt;`real$((probs hside)`cprob));
 r[hks]: enlist each raze (`real$ $[hside=`l;1;1]* prd hdgwtp; hdgwtp);  //TODO - use the skew logic to rebalance the sides
 r[`hedge]:hside;
 //Hedge wt calculation - approach 1 with binomial probability. Simpler, more maintainable
 r[`hedgewt1]: prd 1 - 1 _ {x%sum x} (probs hside)`probl; //Calculate binomial probability of no fill in rest of the periods - normalize the prob of fills first and then multiply prob of no fills for all of periods

 //Hedge wt calculation - approach 2 with probability of hits in rest of the periods given current fill. 
 // Let f be target hedge fraction (cprob i.e. p), n be number of periods remaining, and f' be the fraction filled in each of subsequent periods given current fill. Then, f = p*f'*n/(1-p)
 prb: `real$(first (probs hside)`probl)%(sum (probs hside)`probl);
 r[`hedgewt2]: prb*0.6e*(4 - inp`idx)%(1 - prb);

 //Append new dictionary to init as a table and flip back to dict
 :flip (flip init) uj flip r;
 }

//Realized ibetcalc - we use realized fill dict rfdict and hedge sides to calculate realized hedge sizes. Fill sizes are 
// assumed to be close to 0
ribetcalc:{[ci;missfill;tfill;init] 
  r1: {[missfill1;tfill1;bets;idx] ibetcalc[missfill1;1.0;;]/[(`hf`lf)!(enlist bets[0];enlist bets[1]);genInp[idx;tfill1]]}[missfill;tfill;init;] ci; 
  //Get hedgesides and do adjustment for respective multipliers
  hsides: 1 _ exec hedge from r1;
  hmults: `real$ {[idx;x] (rfdict (idx;x[0]))$[x[1]=`h;`rhsz;`rlsz] }[ci;] each { ($[0 <= type x;x[0]+1;x+1];y) }\[0;hsides];
  :delete idx,hfm,lfm from flip update hf:hf*1e^hfm, lf:lf*1e^lfm from (update idx:i from flip r1) lj `idx xkey update idx: 1 + til 4 from flip (`hfm`lfm)!flip {[x;y] $[x=`h;(y;1e);(1e;y)]}'[hsides;hmults];
  }

//Get price and fill given bet sizing
getpnf:{[bets;szs;prcs] (sum bets & szs;(bets & szs) wavg prcs)}

getpnf2:{[bets;inp;side] :$[side=`l; getpnf[bets;inp`lmxsize;inp`lprice]; getpnf[bets;inp`hmxsize;inp`hprice]]}

//Logic to place bets
/ tfill is target fill
ibetcalc2h: {[tfill;init;inp] /if inp`cond=0 then fill l using betfracs, else hedge l using cprobl and remaining target fill 
  // first entry should be fill from init with targets
  p: first inp`p;
  idx:inp`idx;
  ci: inp`ci;
  //Note that first init has a different shape than subsequent inits - it just carries target weights for h and l
  if[0 = p; :flip (`ci`idx`p`hfill`hprice`lfill`lprice)!enlist each raze (first ci;first idx;p;getpnf2[(first init)*betFracs100[p][1];inp;`h];getpnf2[(last init)*betFracs100[p][1];inp;`l])];
  fside: $[0=first inp`cond;`l;`h]; 
  hside: $[`l=fside;`h;`l];
  sideKeys:(`h`l)!((`hfill`hprice`hwt);(`lfill`lprice`lwt));
  probKeys:(`h`l)!((`cprobh`cumprobh);(`cprobl`cumprobl));
  / fill side dict keys
  fks: sideKeys fside;
  hks: sideKeys hside;
  r:()!();
  / for fill side, simply use betfrac
  //TODO: Remove fill fraction fix after figuring out what is wrong
  r[fks]: enlist each raze (getpnf2[(((1 2 3 4)!(0.2 0.25 0.25 0.5)) p) * $[fside=`l;1;1] * betFracs100[p][1];inp;fside];enlist(0n;0n));
  /Calculate hedge weight using tfill and sum of all fills so far on hedge size 
  //TODO - look at first fks entry in init to see if missed fill. Then, scale by missed fill
  /hfill: `real$ (max(0;((sum raze init first fks) + (((1 2 3 4)!(1 0.25 0.1 0.05)) p)*tfill) - sum raze init first hks));
  hfill: `real$ tfill;
  //For hedging in last period, reduce hedging size if fill idx is below 1
  fllidx: $[p = 4;ehli[4;ci]$[fside=`l;`lidx;`hidx];0nf];
  //hwt will be 1 anyway for p=4 by design
  /if[(not null fllidx) and (p=4) and (fllidx < 1.5); hfill: `real$max(0;(1*(sum raze init first fks)) - sum raze init first hks);];
  
  hwt: `real$(inp first probKeys hside)%(1 - (inp last probKeys hside));
  // Try unnormalized probabilities for hedging
  /hwt: `real$inp first probKeys hside;
  /if[(ci=7) and p=4;'brk];
  //Calculate target bet fraction using expected fill size
  //TODO: Remove temporary fix for overhedging
  hbetf: (((1 2 3 4)!(1 1 1 1)) p)* 1 * hfill*$[hside=`l;1;1]*hwt%sum betFracs100[p][1]*betFracs100[p][2];
  r[hks]: enlist each raze (getpnf2[hbetf*betFracs100[p][1];inp;hside]; enlist (hfill;hwt));
  r: update ci:first ci, idx:first idx, p:p from r;

  : init uj flip r ;
   
  }

ibetcalc2:{[tfill;init;inp] (uj/) {[tfill;init;inp] ibetcalc2h[tfill;;]/[init;inp],' select h,l,nh,nl,hidx,lidx from inp }[tfill;init;] each 5 cut inp}

/TODO: For fill side, any shortfall could be made up as follows at period 1:
 // - let p be fill probability
 // - if p < 0.1 (say), just do aggressive fills on BBO (i.e., open) 
 // - Otherwise bet normal fill attempt at fraction p, and aggressive fill attempt at fraction 1-p. That way, we are dividing our bets
 // between aggressive and normal fills proportional to the probability of that event

// Inputs: p (period), list of fills, current prob, cum prob (until previous period), target fill (efill)
calcFill:{[p;efill;fks;cprob;cumprob]
  / Sum up list of fills until now
  / if p = 1, get prev fill target: efill*1.3, else proprotional to cumulative probability
  / We ease up in p>1 when we have more accurate information
  / TODO: Removed hard-coded 1.3 value for p=1
  tfillp: efill*$[p = 1; 1%1.3; cumprob]; /target for fills until previous period. 
  tfillc: efill*cprob; / target fill for current period
  / Aggressive only for p=1 may be
  cfill: sum fks; //get cumulative fill so far. This tells us how far we are from target fill
  fillShortfall: max(0; tfillp - cfill); 
  :(`aggr`normal)!(0;tfillc); //Set aggressive fill to 0 for now
 }

ibetcalc3:{[missfill;initscale;maxsize;init;i] 
    beterrs:getBetErrs[i];
    inp1: genInp[i;0.1e];
    lprb: `real$probsh[i;`l][0][0];
    hprb: `real$probsh[i;`h][0][0];
    fside: $[(first init`hf) > first init`lf;`h;`l];
    init1: update p:0, fillside:fside, hcprob: hprb, hcumprob:hprb,lcprob:lprb,lcumprob:lprb from init;
    :ibetcalc3h[missfill;initscale;maxsize;getBetErrs[i];]/[init1;inp1];
 }

getProbs:{[inp]  :(`h`l)!{[x;y] (`cumprob`pprob`cprob)!(sum y#x;x y-1;x y)}[ ;inp`idx] each (inp`hprobs;inp`lprobs);}

ibetcalc3h:{[missfill;initscale;maxsize;beterrs;init;inp] 
 p: count flip init;

 fside: $[`h=inp`hedgeSide;`l;`h];
 sideKeys:  (`h`l)!(`hf`lf);
 fillmissKeys: (`h`l)!(`hm;`lm);
 / fill side dict keys
 fks: sideKeys fside;
 hside: inp`hedgeSide;
 hks: sideKeys hside;
 /Calculate probs for h and l sides
 probs: getProbs inp; 

 r:()!();
 r[`p]: enlist p;
 r[`fillside]: enlist fside;
 r[`state]: enlist $[p=1;((10b)!(`good`bad)) $[fside=`l;(first init`lf) > first init `hf;(first init `lf) < first init`hf];`];
 // This keeps track of whether we have special case of 0 and 15 - turns off as soon as any period condition flips
 r[`trendy]: $[p > 1; all r[`fillside][0] = 1 _ init`fillside;1b;0b];

 //For fill side, set current fill proportional to prob - set scaling of first bet to initscale (min for now), i.e., we assume that subsequent bet sizes are twice that of p=0 bet. In case of no fill in p=0, we assume a missfill
 r[fks]: enlist (max (missfill;initscale*first init fks))*`real$(probs fside)`cprob;
 
 //hbetsize: $[(p > 1) and r[`trendy] and $[`state in key init; init[`state][1] = `bad;0b]; 
 //           (first init hks)*((2 3 4)!(0.25;0.25;0.75)) p;
 //           (max(0;(inp`avgFillSize) - sum raze init hks))*((probs hside)`cprob)%(1 - (probs hside)`cumprob)];
 hbetsize: (max(0;(inp`avgFillSize) - sum raze init hks))*((probs hside)`cprob)%(1 - (probs hside)`cumprob);
 r[hks]: enlist `real$ hbetsize;

 r[`hcprob]: enlist `real$(probs `h)`cprob;
 r[`hcumprob]: enlist `real$((probs `h)`cumprob);
 r[`lcprob] : enlist `real$(probs `l)`cprob;
 r[`lcumprob]: enlist `real$((probs `l)`cumprob);

 //Append new dictionary to init as a table and flip back to dict
 :flip (flip init) uj flip r;
 }


fillStrat:{[betparams;init;tpc] 
  //cond filter, strategy, size gap, bench error - params - max bet size, target bet size (needed for mean targeting)

  p: tpc`p; //Current period
  //Reset init if p = 0
  init:$[p=0;()!();init];
  / important parameters p and cond, max betsize (to adjust for unhedged fills from previous periods)
  / reset init at p=0 - we are walking through tpc. We will build up init on period 0-4, and use it to generate new table
    
  / cond = 0 => fill l, else fill h
  / if fill and p <= 2, fill frac ~ 0.4 at p=1, 0.15 (0.4*0.4) at p=2, 0.05 at p=3

  / Keep track of unhedged fill and fill cost

  / generate idx as well

  } //scan function over tpc1 - use current fill + expected fill to calc fill size for hedging, initially use unit of fills to calculate fills and error wrt benchmark

/index calculations for t`hi <= t`li - pass the flag like 10101b to get indices for different condition flips - different length conditions allowed
getidx2:{[conds] where {all ((count y)#x) = y}[;conds] each (flip (((t`h0) > t`l0; (t`h1) > t`l1;(t`h2) > t`l2;(t`h3) > t`l3;(t`h4) > t`l4)))} 

//TODO:
// - track estimated fill size and hedge sizes (perhaps based on probabilities remaining)
// - keep track of number of flips that have occured so far
// - calculate fill and hedge sizing for current period

betrck1:{[params;x;y]
  cond: (x`cond),y;
  cflip:  $[(last x`cond) = y;0;1];
  flips: (x`flips) + cflip;
  //Get count of conditions - we for now assume to be right for current condition (by observing open)
  i:count cond;
  probs:{[idx;i1]{100*x%sum x} count each group asc idx i1}[;getidx2 cond] each (hidx;lidx);
  cumprobh: `real$sum probs[0] til i;
  cprobh: `real$0e^probs[0] i-1; 
  cumprobl: `real$sum probs[1] til i;
  cprobl: `real$0e^probs[1] i-1;
  hedge:$[y=0b;`h;`l];
  fill:$[hedge=`h;`l;`h];
  hsize:0e;lsize:0e;
  kys: (`h`l)!(`cumprobh`cprobh`chsize;`cumprobl`cprobl`clsize);

  r: (`cond`cumprobh`cprobh`cumprobl`cprobl)!(cond;cumprobh;cprobh;cumprobl;cprobl);
  //For a hedge to fill flip, calculate adjustment
  // Adjustment = (cumprob_prev/cumprob_prev_updated)* target hedge size
  thdgsize: x`thdgsize;
  hdgkeys: kys hedge;
  fllkeys: kys fill;
  
  if[cflip=1;
      mxscaling: ((1 2 3 4)!(1.5 1.5 1.25 1.15e)) flips; / If a flip occurs, get catchup size from params based on number of flips
      thdgsize: `real$max(mxscaling;(x fllkeys[0])%((r fllkeys[0]) - r fllkeys[1]))*thdgsize;
    ];

  / Now compute new hedge size and fill size
  hdgsize: `real$ max(0;100*(r hdgkeys[1])%100); / Subtract cumulative position and then calculate fraction so we don't exceed estimated hedge size
  fllsize: `real $ max(0;((thdgsize* r fllkeys[0])%100) - x fllkeys[2]);
  hsize: $[hedge=`h;hdgsize;fllsize];
  lsize: $[hedge=`l;hdgsize;fllsize];

  // Notes: 
  // - When a flip occurs, the new flip side needs to catch up while new hedge side should relax
  // - We want fills to be overweight than hedge so we can get more profits in subsequent periods instead of losses due to overhedging
  // - For flips, we could add more fill weight when number of flips is 1 or 2. flips > 2 are ~10% prob
  /   (enlist `flipscaling)!enlist ((1 + til 4)!(1.5 1.5 1.25 1.15)) /flip number, allowed max scaling

  //If a flip occurs, get catchup size from params based on number of flips
  /if[cflip=1;(1 2 3 4)!(0.5 1 0.5 0.5) flips;];
  /hdgsize:$[hedge=`h;cprobh;cprobl]*min(0; 100 - sum x`hdgsize);
  /fllsize:min (0, $[fill=`l;cumprobl;cumprobh]*100 - sum x`fllsize);

  :r,(`flips`hedge`fill`chsize`clsize`thdgsize)!(flips;hedge;fill;`real$(x`chsize) + hsize;`real$(x`clsize) + lsize;thdgsize);
  }

/ { cond:01000b; d:(`cond`cumprobh`cprobh`cumprobl`cprobl`flips`hedge`fill`chsize`clsize`thdgsize)!(first cond;20e;20e;40e;40e;0;`h;`l;10e;20e;100e); (enlist d), betrck1[`;;] \[d;1 _ cond] }`

//Code to calculate prob distribution for periods 1 through 4 given condition number from iperms (i.e., 1 => oph > opl)
getCondProb:{[i] 
  //get probs for h and l for period 1-4
  hlprbs: {(`h`l)!{{x%sum x} count each group asc x} each (hidx x;lidx x)} each {(enlist first x),inter\[first x;1 _ x]} didx1 last iperms i;
  //Calculate fill sides
  fsides: ?[0=first iperms i;`l;`h];
  //Calculate cumprob,pprob,cprob for each side -- 0 fill for null period entry
  prbs: { (`h`l)!(4#x;-4#x)} {[x;i] (`cumprob`pprob`cprob)!raze (sum 0f^x til i;0f^x (i-1) + til 2)}'[(hlprbs`h),hlprbs`l;8#1 + til 4]; 
  :(`fside`prbh`prbl)!(fsides;prbs`h;prbs`l);
  }
