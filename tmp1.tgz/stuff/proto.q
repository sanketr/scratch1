
//Dictionary of expected fills for p > 0
pfilld:(0 1 2 3 4)!(1;0.4;0.15;0.05;0.05);
efsize: 60; /Expected fill size for p > 0, when fill happens
colsd:(`l`h)!((`lsize`lprice`clsize`clprice);(`hsize`hprice`chsize`chprice)); /price/size column names for sides


minmax:{[minval;maxval;val] min (maxval; max (minval; val))}
//Function to calculate scaling for p=0 to ensure no unhedged fills greated than max limit
// Can only take value in [0,1]
firstPeriodScale:{[mxsize;cfill] minmax[0;1; (mxsize - cfill)%sum betFracs[0][1]]} /Clipping in hard limit, not expectation

//TODO: Bet sizing function
// p=0 - limit fill to max size
// p=4 - clip hedge side size to avoid overflow
// Take maxsize,p,bet sizes,probs, current fill/hedge
// Output bet sizing 
betScales:{[mxsize;p;fill;probs] 

  //call firstPeriodScale for p=0
  if[p=0; :(`fillscale`hedgescale)!(firstPeriodScale[mxsize;fill`cfill];0)];
  efillscale: minmax[0;1;(mxsize - fill`cfill)%efsize*pfilld[p]] ; / calculate efillscale between [0,1] to control max fill bet - we will simply scale the bet. scale = (maxsize - cfill)/expected fill size => cfill + scale*expected fill size <= maxsize
  / fill frac ~ 0.4 at p=1, 0.15 (0.4*0.4) at p=2, 0.05 at p=3
  efill: (0i^fill`cfill) + efillscale*efsize*pfilld[p]; 

  hbetsize: max(0; (efill - fill`chedge)) * ((probs`hedge)`cprob)%(1 - (probs`hedge)`cumprob) ; 
  /calculate hscale for current period for bet scaling given hbetsize above - can be greater than 1
  hedgescale: hbetsize%(sum $[p=4;1;betFracs[p][2]]*betFracs[p][1]); //At p=4, we clip in hard limit, not expectation, to avoid overhedging 

  :(`fillscale`hedgescale`efill`hbetsize)!(efillscale;hedgescale;efill;hbetsize); 

  }

/Note: keys starting with "c" are for cumulative, "l" or "h" for respective side
/fillStrat[(enlist `mxsize)!enlist 150i;;]\[(`tbl`betinfo)!(enlist (`idx`fside`p`lsize`hsize`lprice`hprice`clsize`chsize`clprice`chprice)!(0Nj;`;0Nd;0;0;0Nf;0Nf;0;0;0Nf;0Nf);());7#tpc1]
fillStrat:{[betparams;init;tpc] 
  //cond filter, strategy, size gap, bench error - params - max bet size, target bet size (needed for mean targeting)

  p: tpc`p; //Current period
  // Look back at last period - for p=0, this is previous period, else it is previous sub-period
  initl:last init`tbl; 

  //Calculate size and cost basis carries from previous period. Reset cost basis at p=0
  carry:(`lsize`hsize`lprice`hprice)!raze ($[p = 0;(max((initl`clsize) - initl`chsize;0);max((initl`chsize) - initl`clsize;0));(initl`clsize;initl`chsize)];initl`clprice;initl`chprice);

  / For now randomly choose fill side if period=0
  fillSide: $[p=0;first 1?`l`h; 0=tpc`cond;`l;`h]; /cond = 0 => fill l, else fill h
  hedgeSide: $[fillSide=`l;`h;`l]; /hedgeSize is opposite of fill side

  / important parameters p and cond, max betsize (to adjust for unhedged fills from previous periods)
  /Calculate fill bet size, and expected fills
  cfill: (0i^first carry colsd fillSide); /Get fill so far
  chedge: (0i^first carry colsd hedgeSide); /Get hedge so far

  probs:(`fill`hedge)!$[fillSide=`l;::;reverse] ((`cumprob`cprob)!(0f^tpc`cumprobl;1f^tpc`cprobl);(`cumprob`cprob)!(0f^tpc`cumprobh;1f^tpc`cprobh));

  betscale: betScales[betparams`mxsize;p;(`cfill`chedge)!(cfill;chedge) ;probs];
  /Calculate lscale and hscale for l and h side - set to 1 and 0 for p=0, depending on side selected for fill
  lscale:$[fillSide=`l;betscale`fillscale;betscale`hedgescale];
  hscale:$[fillSide=`h;betscale`fillscale;betscale`hedgescale];

  / Bet and hedge position sizing based on previous calculations, get fills after position sizing
  / TODO: Handle the case for p=0 where we bet only one side
  fillsd:(`lsize`lprice`hsize`hprice)!raze {[bets;szs;prcs] (sum bets & szs;(bets & szs) wavg prcs)  }'[(lscale*betFracs[p][1];hscale*betFracs[p][1]);((tpc`lmxsize); tpc`hmxsize);((tpc`lprice);tpc`hprice)];
  fillsd: update clsize:lsize + carry`lsize, chsize:hsize + carry`hsize, clprice: (lsize;carry`lsize) wavg (lprice;carry`lprice), chprice: (hsize;carry`hsize) wavg (hprice;carry`hprice) from fillsd;

  betinfo:(`idx`p`lscale`hscale`efill`hbetsize`lsize`lprice`hsize`hprice)!raze (tpc`idx;p;lscale;hscale;betscale`efill;betscale`hbetsize;fillsd`lsize`lprice`hsize`hprice);

  /if[(20 < count init`tbl) and p=1;'brk];
  
  //Dictionary of data for current period - unit of bet = 1 if p=0 and corresponding fill size > 0
  cprd: (key initl)!(update idx:tpc`idx, fside:fillSide, p:p from fillsd) key initl; //Add fillSide and period information

  :((`tbl`betinfo)!(enlist cprd; enlist betinfo))
  } //scan function over tpc1 - use current fill + expected fill to calc fill size for hedging, initially use unit of fills to calculate fills and error wrt benchmark
