

//Code to generate kalman filter parameters for use in production
cwd: system "cd"; //Get current working directory - we will use it to locate other files for loading
reldir:$[0 = count cwd ss "qsrc";"qsrc/";""]; //get relative directory for locating library files
system "l ",reldir,"stat.q";
system "l ",reldir,"kalman.q";
system "l ",reldir,"btkalman1.q";

locallevel:{[vv;vw;y;n]
  v: (sqrt vv)* norm `int$n;
  w: (sqrt vw)* norm `int$n;
  u_t: y + sums w;
  : u_t + v;}

//Variance of two points 10k apart about be q*1e4 - e.g.: var opens - prev opens
// That is not true of highs and lows which are not consistently spaced apart by 10k
highs:0Nf;closes:0Nf;opens:0Nf;closes5:0Nf;opens5:0Nf;highs5:0Nf;lows:0Nf;lows5:0Nf;ys:0Nf;
genFnH:{[q;p;n]
  yt: locallevel[2.5e-9;q;p;n];
  ys :: ys, yt;
  highs:: highs, max each 10000 cut yt;
  closes:: closes, last each  10000 cut yt;
  closes5 :: closes5,5 cut last each 2000 cut yt;
  opens:: opens, first each 10000 cut yt;
  opens5:: opens5, 5 cut first each 2000 cut yt;
  highs5:: highs5, 5 cut max each 2000 cut yt;
  lows::lows, min each 10000 cut yt;
  lows5:: lows5, 5 cut min each 2000 cut yt;
  .Q.gc[];
  :last yt;
  }

genFn:{[q;p;n] highs::0Nf;closes::0Nf;opens::0Nf;closes5::0Nf;opens5::0Nf;highs5::0Nf;lows::0Nf;lows5::0Nf;ys::0Nf;
  (ceiling n%10e6) genFnH[q;;10e6]\p;
  highs:: 1 _ highs;closes::1 _ closes;opens::1 _ opens;opens5::1 _ opens5;highs5:: 1 _ highs5;lows:: 1 _ lows;lows5:: 1 _ lows5; closes5 :: 1 _ closes5; ys:: 1 _ ys;}

genParams:{[cq] genFn[cq%10000;15000e*cq;50e6];.Q.gc[];
  // Now calculate market parameters, and return
  :calcMktNoiseParams[`h;cq;5;highs;opens,'highs5];

 }

\
//Example usage:
cqs: (1e-6)*xexp[10;] til 20; //Generate 
out: cqs!{delete h from genParams x} each cqs;
`kalmanParams.json 0: enlist .j.j out
//Aeson compatoble json serialization - add key as cq field in each dictionary entry, save as list
`kalmanParamsAeson.json 0: enlist .j.j { update cq:x from out x} each key out;
`:./kalmanParams set out
