system "P 10";

//An empty kalman parameter table that we can use to keep track of parameters
emptyKParamsTbl: delete from enlist (`jump`open`openScalel`openScaleh`gamma`pmeansl`pmeansh`residsl`residsh`q`preds`cprederrsl`cprederrsh)!(0nf;0nf;0nf;0nf;0nf;`float$();`float$();`float$();`float$();0nf;`float$();`float$();`float$());

trackMeanTr:{[dict;varScale;env;z] 
  //z contains open,l5,h5 => 1 + 5 + 5 = 11 observations
  scalel: {$[0 = count x;1f;x]} max avg each flip exec (xexp[;2] residsl)%cprederrsl from (neg 50)#`.[dict];
  scaleh: {$[0 = count x;1f;x]} max avg each flip exec (xexp[;2] residsh)%cprederrsh from (neg 50)#`.[dict];

  adjOpenScalel: 1%{$[(null x) or 0=x;1f;x]} avg exec openScalel from (neg 50)#`.[dict];
  adjOpenScaleh: 1%{$[(null x) or 0=x;1f;x]} avg exec openScaleh from (neg 50)#`.[dict];
  //also correct for range estimation error - better to be on the high side than lower to avoid divergence. The variance scaling above is expected to self-correct if jump adjustment below is corrected
  jump: { (avg x) + dev x } 1f^exec jump from (neg 50)#`.[dict]; 

  if[any null (adjOpenScalel;adjOpenScaleh);'brkNullAdjOpenScales];
  if[any(scalel=0w;scaleh=0w) or any (scalel=-0w;scaleh=-0w);'brkInfiniteScales];

  /if[10 = count `.[dict];'brkTesting];
  //Get separate set of parameters for L and H including mean - we need to keep track of both means
  envParams: calcTradeParamsHL[avg (adjOpenScalel;adjOpenScaleh);varScale;jump;env[0];max (scalel;scaleh)];

  valsl:(0;envParams`meanl) 
    {[priors;params1] newmean[params1[0];params1[1];params1[2];priors[1]]}\ {(x;y;z)}'[mmu[envParams`linv;6#z];envParams`khl;envParams`kl];

  valsh:(0;envParams`meanh) 
    {[priors;params1] newmean[params1[0];params1[1];params1[2];priors[1]]}\ {(x;y;z)}'[mmu[envParams`linv;z[0],-5#z];envParams`khh;envParams`kh];

  //openScale and scale are affected by side  - different means for openScale, same h[0], different residuals and cprederrs for scale
  hprimel: z[0]%envParams`meanl; hprimeh:z[0]%envParams`meanh;
  hh: envParams`khh;
  //Clamp openScale to avoid divergence due to outliers - can have same h[0] in both calculations
  openScale1l: min(5;max(0.2;xexp[(hprimel - 1)%(hh[0] - 1);2]));
  openScale1h: min(5;max(0.2;xexp[(hprimeh - 1)%(hh[0] - 1);2]));
  
  hlbps: 1e4*(envParams`hl)%envParams`open;

  //update dict 
  dict upsert (`jump`open`openScalel`openScaleh`gamma`pmeansl`pmeansh`residsl`residsh`q`preds`cprederrsl`cprederrsh)!(envParams`jump;envParams`open;openScale1l;openScale1h;`float$varScale;last each valsl;last each valsh;first each valsl;first each valsh;envParams`q;envParams`preds;envParams`cprederrsl;envParams`cprederrsh);

  meanl: last last valsl; meanh: last last valsh;
  //Update env to include mean for both L and H
  :(updateTradeEnvHL[env[0];(meanl;meanh)];(`ehl`hl`icq`openScalel`openScaleh`jump`hlbps`pmeansl`pmeansh`residsl`residsh`q`preds`cprederrsl`cprederrsh)!(envParams`ehl;envParams`hl;envParams`icq;openScale1l;openScale1h;envParams`jump;hlbps;last each valsl;last each valsh;first each valsl;first each valsh;envParams`q;envParams`preds;envParams`cprederrsl;envParams`cprederrsl));
  }

updateTradeEnvHL:{[env;pmeans]
    :update idx:idx+1, meanl: pmeans[0], meanh: pmeans[1] from env;  //go to next entry in backtesting data while we have inputs
  }

//scale is used for jump adjustment
calcTradeParamsHL:{[openScale;varScale;jump1;env;scale]
    //Get i, table and dict of rank of next hl from env - we will use that to get Q for current period
    r: `.[env`tbl] env`idx;
    stats: `.[env`stats];
    prhlbps: 500^r`prhlbps; //Set to mean in case of null entry for i=0
    open: r`o; //Open price - need it to calculate H
    //Look up previous hl in stats, and get expected HL for current period
    cstats: (0!stats) min (-1 + count stats; 1 + (exec hlbps from stats) bin 2f^r`phlbps);
    //hard-coded min-limit of 7f (rank 150) for now
    ehl: jump1 * (max (2f;(2f^r`phlbps))) * ((cstats`nhlbps)%(cstats`hlbps)) * 1e-4 * open;
    if[(null ehl) or ehl=0;'brkInvalidEhl];
    icq: scale*xexp[ehl%1.5958;2];
    cqkey: (asc key out) max(0;(asc key out) bin `float$icq); /get the nearest cq key in param lookup table, scale by multiple of that below
    kparams:calcKParams[;open;icq%cqkey;openScale;varScale;out[cqkey]] each `l`h; 
    // Record jump for current period so we can do mean correction in updateTradeEnv in case of outlier variance jump 
    jump: max (0.1;(r`hl)%ehl); 
    //Note: get the prior kalman mean from env. Note kalman h parameters are named khl etc. to prevent clash with hl (h-l)
   :(`ehl`hl`open`icq`jump`khl`khh`kl`kh`q`preds`cprederrsl`cprederrsh`linv`meanl`meanh)!(ehl;r`hl;r`o;icq;jump;kparams[0]`hl;kparams[1]`hh;kparams[0]`k;kparams[1]`k;kparams[0]`q;kparams[0]`preds;kparams[0]`cprederr;kparams[1]`cprederr;kparams[0]`linv;env`meanl;env`meanh);
  }

//Return diagnostics of kalman filter given filter table, and actual observations
diagnosticsHL:{[tbl;obs]
    probsl:{(count where x > 1)%count x} each flip exec (abs (obs[;0] - pmeansl))%sqrt preds from tbl; 
    probsh:{(count where x > 1)%count x} each flip exec (abs (obs[;1] - pmeansh))%sqrt preds from tbl; 
    residsl:avg each flip exec residsl from tbl;
    residsh:avg each flip exec residsh from tbl;
    multsl: avg each flip exec residsl%cprederrsl from select xexp[;2] each residsl, cprederrsl from tbl;
    multsh: avg each flip exec residsh%cprederrsh from select xexp[;2] each residsh, cprederrsh from tbl;
    hlbps: (`muhlbps`maxhlbps)!{(avg x;max x)} exec hlbps from tbl;
    :hlbps,(`multsl`multsh`probsl`probsh`residsl`residsh)!(multsl;multsh;probsl;probsh;residsl;residsh);
  }

//floor ticksize specified by tick
ticksize:{[tick;p] tick*p div tick}

/function to calculate variance scaling - ln 5 = 1.61
vargamma:{[hlbps;obsbps] (2%1.61)*log hlbps%1.595*obsbps}

//Get dictionary of kalman parameters
out: get `:./kalmanParams/kalmanParams;

\ 
Backtesting over t1 - choose variance scaling power, number of entries to drop from beginning, and side
q)tmp2: {[x;y;gamma] a::emptyKParamsTbl; mtake:min(y;(count opens) - (x+1));tmp1: trackMeanTr[`a;gamma;;] \ [ ((`tbl`stats`idx`meanl`meanh)!(`t1;`stats;x;first (x-1) _ lows;first (x-1) _ highs);()!());mtake # -1 _ x _ opens,'lows5,'highs5]; show diagnosticsHL[last each tmp1;mtake # -1 _ x _ lows,'highs]; :tmp1}[1;50000;0.75e]
maxhlbps| 2273.294707
multsl  | 0.5907334937 0.823197163 0.8909046442 0.8592907864 0.8313522143 0.833178368
multsh  | 0.5922866032 0.8906808768 0.9419960383 0.887436102 0.8821429571 0.8842834055
probsl  | 0.17996 0.18022 0.17914 0.2476 0.29896 0.3213
probsh  | 0.18318 0.18024 0.17892 0.24788 0.29828 0.32094
residsl | -0.06155327504 0.04715123268 -0.04075727307 0.02758819983 0.01562151608 0.01180125681
residsh | 0.06201301575 -0.06363705894 0.006946172758 0.03191093188 -0.005564270155 -0.02051056753
