\l qsrc/stat.q
\l qsrc/kalman.q

//Set random seed
system "S ",string floor (`long$.z.p)%1e9;

//Factorial
fac: {[n] prd 1 + til n}
//n C k combinations
nck: {[n;k] fac[n]%fac[n-k]*fac[k]}
//Binomial trials - given p and n trials, prob of k successes
binomp:{[p;n;k] nck[n;k]*xexp[p;k]*xexp[1-p;n-k]}

//Binomial trials, p, n and at least r successes - sum up probability of
// all outcomes with r until n successes
binomt:{[p;n;r]  sum r _ binomp[p;n;] each til n+1} 

/Rounding to digit n
round:{[n;x] xexp[10;neg n]*floor (x*xexp[10;n]) + 0.5}
/Price to nearest ticksize specified by tick
tickprice:{[tick;p] tick*round[0;p%tick]}
//Bet sizing of positions given probability vector and target size
betsizes:{[p;s] `int$round[0;] s%(count p)*p}

//Bet sizing for consecutive periods under the assumption that earlier hits appear in consecutive hits
//Given ordered probability vector where ith entry is ith hit in chronological order, return fractions to bet
// Bet Size ~ 1/(n_i* sum p_is)
// q)450*pbetsizes 0.3 0.14 0.12 0.14
// 161 214 321 643f
pbetsizes:{[p] {1%x[0]*sum x[1]} (reverse 1 + til count p;p)}

//Bet averaging - return list of filled price and filled size given list of probabilities p, prices
//TODO - supply betsizes and limit prices depending on buy/sell
/ a:avg each flip {[n;m] {[x;i] avg x where i}'[ps[n];ps[n] > pmeans[n] - m*sqrt preds[n]]}'[til 5;1 1 1.2 1.4 1.4]
/ b:{[x;i] $[null x;first ps[0][i+1];x] }'[a;til count a]; {(avg x)%dev x} avg each 500 cut b - lows
betaveraging:{[p;prices;sign]
    prbs: $[sign=`sell;1-p;p]; //In case of sell, lowest price is highest probability
    bs: betsizes[prbs;100]%100;
    limitprs: xn each p; //Calculate limit prices for each bet size
    idx:  limitprs bin prices; //Binary search - in case of sell, from lowest to highest price => we take i. In case of buy, from highest to lowest => we drop lowest i
    :flip (`price`size)!flip {[b;p;takefn;i]  (sum takefn[i+1;b]*takefn[i+1;p];sum takefn[i+1;b])}[bs;limitprs;$[sign=`sell;#;_];] each idx;
  }

sr:{[p;n] xexp[n;0.5]*(-1 + 2*p)%2*sqrt p*(1-p) }

//Validate this one against notes for accuracy
srf:{[p;n;f] n*(-1 + 2*p)%sqrt (4*n*p*(1-p)*(1+xexp[f;2])) + (xexp[f*n*(-1 + 2*p);2])}
srf2:{[p;n;f] xexp[n;0.5]*(-1 + 2*p)%sqrt ((1 - p)*p*4) + 0.31*xexp[f;2]}

/Gambler's ruin notes: http://www.columbia.edu/~ks20/FE-Notes/4700-07-Notes-GR.pdf
/Gambler's ruin probability - i is starting capital
rp:{[p;i] xexp[(1-p)%p;i]}

//Kelly max optimal leverage wrt cash for geometric return given p,h (hit return), l (loss return)
//Derivation in appendix: https://blogs.cfainstitute.org/investor/2018/06/14/the-kelly-criterion-you-dont-know-the-half-of-it/
kellyf: {[p;h;l] (p%l) - (1-p)%h}

//Calculate hidden variance given tick size of 0.5, and probability p of price changes
// For tick size of 0.5 and variance of 2.5e-4, fill probability is ~0.025
// For variance v = n*2.5e-4 (n times given benchmark variance 2.5e-4), p = 0.025*sqrt n => v = (p%0.025)^2 * 2.5e-4
impliedvar:{[p] xexp[p%0.025;2]*2.5e-4} 

// From range of random walk:
//Given average h-l, and n samples, impVariance = n*impVar' = (mu^2)*pi/8 => impVar' = (mu^2)*pi/(8*n)
impVar:{[mu;n] xexp[mu;2]*pi%8*n}

//Implied probability given price variance
//2.5*sigma = 0.994%
//Let t = ticksize. Then, when sigma = t*2.5*0.5 (half of each interval) => price change very likely
// So, price change every n = t*2.5*0.5/sqrt(var) => p = 1%n
impliedprob:{[t;v] 1%t*2.5*0.5%sqrt v}

locallevel:{[vv;vw;y;n]
  v: (sqrt vv)* norm `int$n;
  w: (sqrt vw)* norm `int$n;
  u_t: y + sums w;
  : u_t + v;}

//Variance of two points 10k apart about be q*1e4 - e.g.: var opens - prev opens
// That is not true of highs and lows which are not consistently spaced apart by 10k
highs:0Nf;closes:0Nf;opens:0Nf;closes5:0Nf;opens5:0Nf;highs5:0Nf;lows:0Nf;lows5:0Nf;ys:0Nf;
genFnH:{[q;p;n]
  yt: locallevel[2.5e-9;q;p;n];
  ys :: ys, yt;
  highs:: highs, max each 10000 cut yt;
  closes:: closes, last each  10000 cut yt;
  closes5 :: closes5,5 cut last each 2000 cut yt;
  opens:: opens, first each 10000 cut yt;
  opens5:: opens5, 5 cut first each 2000 cut yt;
  highs5:: highs5, 5 cut max each 2000 cut yt;
  lows::lows, min each 10000 cut yt;
  lows5:: lows5, 5 cut min each 2000 cut yt;
  .Q.gc[];
  :last yt;
  }
genFn:{[q;p;n] highs::0Nf;closes::0Nf;opens::0Nf;closes5::0Nf;opens5::0Nf;highs5::0Nf;lows::0Nf;lows5::0Nf;ys::0Nf;
  (ceiling n%10e6) genFnH[q;;10e6]\p;
  highs:: 1 _ highs;closes::1 _ closes;opens::1 _ opens;opens5::1 _ opens5;highs5:: 1 _ highs5;lows:: 1 _ lows;lows5:: 1 _ lows5; closes5 :: 1 _ closes5; ys:: 1 _ ys;}

genFn[2.5e-4;2750;50e6];.Q.gc[];

//TODO
//z - generate observations tagged with keys, given initial price and price variance
//h,covmat,cormat,hbar,m,mbar,hbar,rbar,q,cq,linv
//Generate pred covar, measure covars, kalman gains and cov pred error in steady state given q,hbar,mbar,rbar
//Generate measure means, pair with measure covars given z,linv,hbar,k - needed for backtesting
//Check for accuracy of predictions - validation function
// Backtesting - yt, up or down relative to start,%age of volume cap,pmeans,pdevs


//Calculate for highs
//Covariance matrix for measurements
h: raze (avg opens%highs;avg each flip highs5%highs);
covmat: cvm (enlist opens - h[0]*highs),flip {[x;y;z] (y-x*z)}[;;1_h]'[highs;highs5];
cormat: crm (enlist opens - h[0]*highs),flip {[x;y;z] (y-x*z)}[;;1_h]'[highs;highs5];

// Measurement noise calculation
//Be careful - order of subtraction is reversed here because of process noise
m1: cov[highs - prev highs;] each  (enlist opens - h[0]*highs), flip {y-x*z}[;;1_h]'[highs;highs5];
m1a: raze flip mmu[inv first ldl covmat; flip enlist m1];
h1: raze flip mmu[inv first ldl covmat; flip enlist h];
r1: {x y}'[last ldl covmat ;til count covmat];
q: var highs - prev highs;

//Calculate prediction deviation with steady state covariance - show in bps
0N!"Uncertainty for highs in bps - open, end 1,end 2,end 3,end 4,end 5";
0N!(1e4%2750)*sqrt preds: last hpreds: calcPredCov[q;h1;m1a;r1];
ck0: first hpreds; //Steady state measurement covariance for initial measurement

z: opens,'highs5;
linv: {[a;b;c] raze (a[b] til 1 + b),(c-b+1)#0f}[inv first ldl covmat;;count covmat] each til count covmat;
zbar: mmu[linv;] each z;

params1: {(`k`cprederr)!(last each x;last each (-1_) each x)}(ck0;0f;0f) covfusion \ {[x;y;z](x;y;z)}'[h1;m1a;r1];
/Check pdf of predicted mean and covariance vs actual mean
0N!{(count x  where (abs x) > y)%count x}'[flip (raze each (1#1_) each (2750;(count first zbar)#0f;(count first zbar)#0f) {[init;z;h;k] vals:(0;init[0]) {[x;y] newmean[y[0];y[1];y[2];x[1]]}\ {(x;y;z)}'[z;h;k]; :(last last vals;last each vals;first each vals)}[;;h1;params1`k] \ zbar) - highs;sqrt preds];

// Let us check the hit ratios

/Predict the means for each of the six (including the one after fifth) intervals - we are interested in only first 5
pmeans: flip (raze each (1#1_) each (2750;(count first zbar)#0f;(count first zbar)#0f) {[init;z;h;k] vals:(0;init[0]) {[x;y] newmean[y[0];y[1];y[2];x[1]]}\ {(x;y;z)}'[z;h;k]; :(last last vals;last each vals;first each vals)}[;;h1;params1`k] \ zbar)
/Prices for each of the five intervals - each price is for one unit
ps: flip (5 cut 2000 cut ys);
show {(`volume`prob)!(round[0;] avg x where x > 0;round[2;] (count x where x > 0)%count x)} each {[n;x]  {count where x} each  ps[n] > pmeans[n] - x*sqrt preds[n]}'[0 1 2 3 4;1 1 1.2 1.6 1.8];

//Calculate measurement covariances for close
ccovmat: cvm (enlist closes - last each opens5), (enlist closes - (last -1  _) each lows5), (enlist closes - (last -1 _) each highs5);
ccormat: crm (enlist closes - last each opens5), (enlist closes - (last -1  _) each lows5), (enlist closes - (last -1 _) each highs5);


//Cross-measurement noise for close process wrt measurements
cm1: cov[closes - prev closes;] each (enlist (last each opens5) - closes), (enlist ((last -1  _) each lows5) - closes), (enlist ((last -1 _) each highs5) - closes);
cm1a: raze flip mmu[inv first ldl ccovmat; flip enlist cm1]; /whitened noise
ch1: raze flip mmu[inv first ldl ccovmat; flip enlist 3#1f]; /whitened gain matrix
cr1: {x y}'[last ldl ccovmat ;til count ccovmat]; /whitened measurement noise
cq: var closes - prev closes;

cck0: max steadycovpredh[1;first ch1;cq;first cm1a;first cr1];
cck0: cq + first last (cck0;0;0;0) covfusion \ {(x;y;z)}' [ch1;cm1a;cr1];

/0N!"Uncertainty for closes in bps - open of 5, low of 4, high of 4";
/0N!(1e4%2750)*sqrt first each (cck0;0;0;0) covfusion \ {(x;y;z)}'[ch1;cm1a;cr1];

/
z: (((neg sqrt cq) + first highs)^prev lows),'opens,'highs5;
linv: {[a;b;c] raze (a[b] til 1 + b),(c-b+1)#0f}[inv first ldl covmat;;count covmat] each til count covmat;
zbar: mmu[linv;] each z;

params1: {(`k`cprederr)!(last each x;last each (-1_) each x)}(ck0;0f;0f) covfusionadj \ {[x;y;z;u](x;y;z;u)}'[h1;m1a;r1;raze (2#1f;5#1f)]

/ Check the pdf of reisduals now with 0 mean and cov pred error - looks good
{(count x  where (abs x) > y)%count x}'[flip raze (1#2_) each  (2750;(count first zbar)#0f;(count first zbar)#0f) {[init;z;h;k] vals:(0;init[0]) {[x;y] newmean[y[0];y[1];y[2];x[1]]}\ {(x;y;z)}'[z;h;k]; :(last last vals;last each vals;first each vals)}[;;h1;params1`k] \ zbar;sqrt params1`cprederr]
0.0502 0.3668 0.3066 0.3004 0.2936 0.3026 0.3002

/Check pdf of predicted mean and covariance vs actual mean
{(count x  where (abs x) > y)%count x}'[flip (raze each (1#1_) each (2750;(count first zbar)#0f;(count first zbar)#0f) {[init;z;h;k] vals:(0;init[0]) {[x;y] newmean[y[0];y[1];y[2];x[1]]}\ {(x;y;z)}'[z;h;k]; :(last last vals;last each vals;first each vals)}[;;h1;params1`k] \ zbar) - highs;sqrt first each (ck0;0f;0f) covfusionadj \ {[x;y;z;u](x;y;z;u)}'[h1;m1a;r1;raze (2#1f;5#1f)]]
0.3156 0.278 0.2082 0.2256 0.2662 0.2764 0.2864
