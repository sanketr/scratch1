\l db

\P 2
\c 25 120
//Random seeding
system "S ",string `int$.z.T;

dt: first 1?date;
// March 2020 crash window: Start time: 2020.03.12 at 8am UTC, End time: 2020.03.13 at 4am UTC
// deviation of mdev trade imbalance (sell/total) vs mdev price change (not prices) as documented here (fig 8): https://blog.kaiko.com/crypto-black-thursday-under-the-microscope-a86770df5c29
a: update dprice:deltas price from select date,time,price,side,size from select from trade where date within (2020.01.01;2020.03.21),sym=`XBTUSD;

update dprice:0.0e from `a where i=0; //Mark first price change as 0 as well
chunkSize: 480;
nSamples: 10000;

// Emit 1b as last element on price change
csize: {[x;y;z] $[y=0.0;(x[0]+z[0];z[1];0b);(z[0];z[1];1b)]}\[(0i;exec first price from a;0b);exec dprice from a;(exec size from a),'exec price from a];
a: (a,' flip (`csize`change)!(csize[;0];csize[;2]));
update pprice:prev price, psize:prev csize,pside:prev side from `a;

//Get prev price and cumulate size where change = 1
a1: select date,time,price:pprice, size:psize, side:pside, idx:i from a where change=1;

//Get carryover of chunks in excess of chunkSize 
carry: `real$ ({ (x mod chunkSize) + y }\) exec size from a1;

update chunked:carry - leftover from update leftover: `real$carry mod chunkSize from update carry:carry from `a1;

update pleftover:prev leftover from `a1;
update pleftover:0e from `a1 where i = 0;

//Calculate vwap now - do vwap of size in current period with leftover of previous price period
vwap: ({[x;y;z] z wavg (y;x)})\[0; exec price from a1;flip exec (size;pleftover) from a1];

//Set actual price
update pcostbasis:0e^prev costbasis from update costbasis:vwap from `a1;

//Cut up prices in chunks of chunkSize now - divide each chunked size by chunkSize, and repeat prices that many times
a2: nSamples cut raze  {x#y} '[`int$exec chunked%chunkSize from a1;exec costbasis from a1] ;

//Calculate highs/lows/opens
highs5: { max each (floor (nSamples)%5) cut x} each a2;
lows5: { min each (floor (nSamples)%5) cut x} each a2;
opens: first each a2;
highs: max each a2; lows: min each a2;

//Indices in trades, for each entry in a2 - that way, we can track trade entries corresponding to an event
aIdx: {(first x;last x)} each nSamples cut raze {x#y} '[`int$exec chunked%chunkSize from a1;exec idx from a1] ;

//Calculate buyfraction for a1 - (pbuyfrac*prev notional + buyInd*current notional)/(prev notional + current notional)
// Prev Notional = pleftover*pcostbasis, Current Notional = size*costbasis
// Carry = Size + Prev Leftover

/ buyFracs: {[pbfrac;inp] ((pbfrac*(inp`pleftover)*(inp`pcostbasis)) + (inp`buyInd)*(inp`size)*(inp`costbasis))%((inp`pleftover)*(inp`pcostbasis)) + (inp`size)*(inp`costbasis)}\[$[a1[0][`side]=`Buy;1e;0e]; flip exec pleftover,pcostbasis,buyInd:?[side=`Buy;1e;0e],size, costbasis from a1];

// Use starting and ending indices in a1 above, together with buyfracs to calculate buyfraction by notional - each "chunked" size has buyfrac. Multiply it by costbasis to get notional for buy fractions
/ update cbuynotnl: chunked*buyFracs*costbasis from `a1; //Note buyfracs is a global variable above
//bfracs is aligned to t1
/ bfracs: {exec (sum cbuynotnl)%(sum costbasis*chunked) from a1 where i within x} each {(first x;last x)} each nSamples cut raze {x#y} '[`int$exec chunked%chunkSize from a1;exec i from a1]; //We calculate indices in a1 for each nSamples chunks in a2, and calculate buyfraction

//Store high/low indices - should follow arc sine distibution
idxs: (`hidx`lidx)! flip {[x] mu:max x;ml:min x; n:`int$(nSamples)%5; (where mu = max each n  cut x;where ml= min each n cut x)} each a2;
//Take average of multiple hits if there, and convert to integer
hidx: ceiling avg each idxs`hidx; 
nhidx:next hidx; 
lidx: ceiling avg each idxs`lidx; nlidx: next lidx;

//Calculate implied variance - mu/dev should be around 3.35 when targeting beta calculations
impvar:{[hl;n] (1%n)*xexp[avg hl%1.5958;2]}
getNoiseBeta:{[ivars] update beta:impvar%aivar from select avg hlbps, r:avg hl%dev hl, impvar:impvar[hl;nSamples],aivar:avg ivar,n:count i from rt where ivar within ivars}

t1: {(`ivar`ivar2000`hlbps`hl`h`l`c`o)!(avg xexp[x - prev x;2];(1%2000)*{first 1 _ xexp[x - prev x;2]} raze first each 2000 cut x ; 1e4*log (max x)%min x; (max x) - min x;max x;min x;last x;first x)} each a2;
update pc:prev c, po:prev o, ph:prev h, pl: prev l, pivar:prev ivar, aivar:impvar[;nSamples] each hl from `t1;
update paivar:prev aivar from `t1;
//update pbfrac:prev bfrac from update bfrac:bfracs from `t1;

varChunk:0.0000006;
rt: update r:hl%hl1 from select avg hl, dev hl, n:count i, avg hlbps by varChunk xbar ivar from t1;

/r1: select n wavg r, avg hl, dev hl, avg hlbps, sum n from select from rt where n > 4;
/r2: select n wavg r, avg hl, dev hl, avg hlbps, sum n from select from rt where n <= 4, not hl1=0, r < 100;

r1: select n wavg r, sum n, n wavg hlbps, avgSampleSize:avg n from (update r:hl%hl1 from select avg hl, dev hl, n:count i, avg hlbps by varChunk xbar ivar from t1 )  where r < 100;
r2: select r:avg hl%dev hl, sum n, n wavg avg hlbps, avgSampleSize:avg n from (update r:hl%hl1 from select avg hl, dev hl, n:count i, avg hlbps by varChunk xbar ivar from t1 )  where r > 100;

//Leave out r from r2 for now because it is mixture of distributions, and so polluted - ratio in r1 serves as proxy for now
show (select n wavg hlbps, sum n from r1,r2),' select r, avgSampleSize from r1;
show {100*x%sum x} count each group asc raze idxs`hidx;
show {100*x%sum x} count each group asc raze idxs`lidx;

//Check how randomized the movements are - e.g., hq and lq should be ~0.73 times cq (i.e. 2*(1 - 2/pi) - twice of half normal distribution variance), ho and lo should be about equal (needed for h in kalman filter), and half of mu
show select cq: var c - pc, mu: (avg h - l), hq: var h - ph, lq: var l - pl, hchg: avg h - ph, lchg: avg l - pl, cchg:avg c - pc, ho: avg h - o, lo:avg o - l,  n:count i from t1 where ivar within (0.0001;0.0003);

.Q.gc[];
/select from update impvar: impvar[;nSamples] each hl from update r:hq%cq from  select from (update r:hl%hl1 from select avg hl, dev hl, hq:(1%nSamples)*var h - ph, lq: (1%nSamples)*var l - pl, cq:(var c - pc)%nSamples,  n:count i, avg hlbps by 0.001 xbar ivar from t1 ) where n > 5


////////// Notes ///////// 
// Noise beta might be dependent on ratio of chunk size to natural order book size. For example, with chunk size of 480, noise variance beta is around 2.7 avg. Reducing chunk size to 1/4th brings the noise beta down to 1.29 avg, about half.
//Volatility related hlbps might be a power of 0.742, i.e., variance bends down as xexp[n;0.742] with volume time scaling of n
/////////////////////////

// try to denoise the ratio of average hl to dev hl 
// - sort in increasing order of ivar, average once to denoise, and then compute
//select r:avg uhl%dev uhl, hq:var h - ph, cq: var c - pc,hchg: avg h - ph, lchg: avg l - pl, cchg:avg c - pc, ho: avg h - o, lo:avg o - l, avg uhl, med uhl, ivar:avg ivar, aivar: impvar[avg uhl;nSamples], beta:avg (impvar[;nSamples] each uhl)%ivar by 2500 xbar i from (select from (update uhl:2 mavg h - l  from `ivar xasc t1) where (h - l) > 0)

//update rhl:1000 xrank hl  from `t1

//avg each {?[x=0w;1;x]} each flip {x where 14 = count each x} exec rdecay from select rdecay, rhl from select rhl:first rhl, rdecay:(1 _ rhl)%(first rhl), first hl, lhl: last hl, uhl: avg 1 _ hl, medr: med 1 _ rhl, minr: min 1 _ rhl, maxr: max 1 _ rhl by idx from raze {select hl,rhl,idx:first i from t1 where i in x} each {[x] x + til min(15;(count t1) - x)} each exec i from t1 where rhl within (150;450)

//h scaling for periods ~0.625 to match what we observe by variances - hrst calculates theoretical h
// hrstfn: {[cq;nprd;open] 1 + xexp[cq;0.5]%xexp[nprd;0.5]*open } //calculate theoretical h for highs%higsh5 or lows5%lows
// {[x] raze (avg avg `float$(highs%highs5) -1 _ x[0];avg avg `float$(lows5%lows) -1 _ x[0];hrstfn[x[1];xexp[5;0.625];avg highs x[0]]) } each {[x] (exec i from t1 where ivar within -1 _ x;nSamples*last x) } each -1 _ flip value exec ivar,nivar,aivar from update nivar:next ivar from select ivar:avg ivar, aivar: impvar[avg uhl;nSamples], beta:avg (impvar[;nSamples] each uhl)%ivar by 2500 xbar i from (select from (update uhl:2 mavg h - l  from `ivar xasc t1) where (h - l) > 0)
