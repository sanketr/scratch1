//To do:
//- load highs5, lows5

\l qsrc/sim.q
\l qsrc/preds.q

nlparams: calcKNoiseParams[lows;opens,'lows5];
klparams: calcKPredParams[nlparams;lows;opens,'lows5];
klpreds: predict[klparams;nlparams;opens,'lows5;lows];

// load plmeans,hidx,lidx 
plmeans: flip klpreds`pmeans;
hidx: raze where each highs5=highs;
lidx: raze where each lows5=lows;
nhidx: next hidx; nlidx: next lidx;

// load distance of opens5 wrt means -
phds: flip {[i] pmeans[i] - opens5[;i]}'[til 4]; 
plds:flip {[i] opens5[;i] - plmeans[i]}'[til 4];

// load fillss on lows and highs along with volume fills
dists: 4e - 0.25e*til 25; //Bet distance as multiple of sd from means
fhs:  dists! flip each {[n;m] {[x;i] $[ct:count where i;(x;ct);(0n;ct)]}'[pmeans[n] - m*sqrt preds[n];ps[n] > pmeans[n] - m*sqrt preds[n]]}'[til 5;] each  (5#) each dists;
fls: dists! flip each {[n;m] {[x;i] $[ct:count where i;(x;ct);(0n;ct)]}'[plmeans[n] + m*sqrt preds[n];ps[n] < plmeans[n] + m*sqrt preds[n]]}'[til 5;] each  (5#) each dists;

plows:prev lows;nlows:next lows;phighs:prev highs;nhighs:next highs;
hict: count each group asc hidx; lict: count each group asc lidx;

//Create buoys for highs and lows - a buoy is the best hit
buoys: {[n;data] ks: key data; d1:{[n;x] {[n;x] not null x[;0][n]}[n;] each x}[n;] each data; {[x;ks;n] 0w^ks last where x[;n]}[d1 key fls;ks;] each til count first d1 }

lowBuoys: (`$ ("l",) each string each til 5)!buoys[;fls] each til 5;
highBuoys:  (`$ ("h",) each string each til 5)!buoys[;fhs] each til 5;

t: (flip lowBuoys),' flip highBuoys;
update hidx:hidx, lidx:lidx from `t;

//Best fill price table - high and low respectively
pht: flip (`ph0`ph1`ph2`ph3`ph4)! {[n;x] {x last where not null x} each {[n;x] x[;n][;0]}[n;] each x}[;flip value fhs] each til 5;
plt: flip (`pl0`pl1`pl2`pl3`pl4)! {[n;x] {x last where not null x} each {[n;x] x[;n][;0]}[n;] each x}[;flip value fls] each til 5;


t: t ,' pht ,' plt;
update highs0:highs5[;0],highs1:highs5[;1],highs2:highs5[;2],highs3:highs5[;3],highs4:highs5[;4]from `t;
update lows0:lows5[;0],lows1:lows5[;1],lows2:lows5[;2],lows3:lows5[;3],lows4:lows5[;4]from `t;
update opens0:opens5[;0],opens1:opens5[;1],opens2:opens5[;2],opens3:opens5[;3],opens4:opens5[;2] from `t;
update low:lows, high:highs,open:opens from `t;
update nlow:next low, plow:prev low, nhigh:next high, phigh:prev high from `t;

tint:t; //Copy t to internal t that we will use - this avoids bugs if we inadvertently overwrite t with something else

t1hi0: `n xdesc select hl:avg high - low, n:count i, vol125:{avg {x[;1]} {x[0]} each (fhs 1.25e) x} i, vol15:{avg {x[;1]} {x[0]} each (fhs 1.5e) x} i by h0>l0,h1>l1,h2>l2,h3>l3 from t where hidx=0;
t1: `n xdesc select hl:avg high - low, nhl:avg nhigh - low, hnl:avg high - nlow, n:count i, vol125:{avg {x[;1]} {x[0]} each (fhs 1.25e) x} i, vol15:{avg {x[;1]} {x[0]} each (fhs 1.5e) x} i, hidx:round[1;] avg hidx, lidx:round[1;] avg lidx by h0>l0,h1>l1,h2>l2,h3>l3 from t;

//Generate permutations of boolean flags from length 1 until 4
flags: raze {distinct (y#) each x}[(01b cross 01b)  cross (01b cross 01b)] each 1 _ til 5;
dh:  { x!{{100*x%sum x} exec count i by hidx from t where all ((count x)#(h0>l0;h1>l1;h2>l2;h3>l3)) = x} each x} flags;
dl:  { x!{{100*x%sum x} exec count i by lidx from t where all ((count x)#(h0>l0;h1>l1;h2>l2;h3>l3)) = x} each x} flags;

ah: dists!{[f] {(x[;0];x[;1])} each fhs f} each dists;
al: dists!{[f] {(x[;0];x[;1])} each fls f} each dists;

//TODO: 
// - get i,sides,bets
// - function calculation of above
// - function to calculate error
// - function to calculate fills
getSide: {[side] $[side=`h;ah;side=`l;al;'wrongarg]};
getSidePrices:{[side;sigma;i] :side[`real$sigma][;0][;i]}; /i from 0 through 4
getSideFills: {[side;sigma;i] :side[`real$sigma][;1][;i]}; /i from 0 through 4

//Function to calculate simulated volume within +- x dollars of high/low - i.e., spread of (high - x) - (low + x) = (high - low) - 2*x
spreadVolume: {[sprd] avg {[i;sprd] sum {[n;i;sprd] count where (ps[n][i] < lows[i]+sprd) or (ps[n][i] > highs[i]-sprd)}[;i;sprd] each til 5}[;sprd] each til 5000};

//Calculate high/low fills, prices centered around 1,0.75,0.75,0.5,0.25 sigmas
getVolumeOrPrice: {[i;side;sigma;idx] side[sigma][;i][;idx]}
getVolume:getVolumeOrPrice[1];
getPrice:getVolumeOrPrice[0];
getTVolume:{[side;sigma;idx;frac;target] min(;target) frac*getVolume[side;sigma;idx]}

//Get fills and prices given targets
getfps: {[side;frac;idx;sigmas;targets] fillvs: flip getTVolume[side;;idx;frac;]'[sigmas;targets];:flip (fillvs;flip getPrice[side;;idx]'[sigmas]);}

//Group summary - show total, and probability distribution
gs: {show each (sum x;"###";100*sums x%sum x;"###";100*x%sum x);}


//Get bet size proportional to probability for each interval - returns sizes as `h`l dict
//TODO: Must calculate cumulative probs
/getBetSizes:{[flags] {[x;y] `h`l!(0^dh[x][y];0^dl[x][y])}'[{x#y}[;flags] each (raze (1 _ til 5;4));til 5]}

/ Initial testing
/ select pnl:avg (((0.38;0.26;0.0;0.0;0.03) wavg) each flip (ph0;ph1;ph2;ph3;ph4)) - ((0.2;0.06;0.05;0.6;1.04) wavg) each flip (pl0;pl1;pl2;pl3;pl4), n: count i, hl:avg high - low from t where all (h0>l0;h1>l1;h2>l2;h3>l3)=1111b

/q)select avg highs0 - ({(min each flip ((150;250;150);0.3*x[;1])) wavg x[;0]} each flip {[n;f;i] {[n;x]x[;n]}[n;] (fhs f) i}[0;;i] each (1e;1.25e;1.5e)) from t where  all (h0 > l0;h1 > l1;h2 > l2;h3 > l3)=1111b
/highs0   
/---------
/0.3164426

/al:dists!{[f] {(x[;0];where not null x[;0])} each fls f} each dists;
/ah:dists!{[f] {(x[;0];where not null x[;0])} each fhs f} each dists;

/avg (highs - ({((10e;5e;20e;30e;10e)*x[;0]) wavg x[;1]} each {{(sum (1e;1e;2e;2e;4e) where not null x; (1;1;2;2;4) wavg x)} each 5 cut x} each ah[1.25e][;0],'ah[1e][;0],'ah[0.5e][;0],'ah[0e][;0],'ah[-1e][;0])) exec i from t where l2 <= 0.75

/avg (neg lows - ({((5e;2e;8e;5e;5e)*x[;0]) wavg x[;1]} each {{(sum (1e;1e;2e;2e;4e) where not null x; (1;1;2;2;4) wavg x)} each 5 cut x} each al[1.25e][;0],'al[1e][;0],'al[0.5e][;0],'al[0e][;0],'al[-1e][;0])) exec i from t where l2 <= 0.75

/a1: flip (`hsize`h)!flip {(sum (10e;13e;20e;30e;0e)*x[;0];((10e;13e;20e;30e;0e)*x[;0])wavg x[;1])} each {{(sum (1e;1e;2e;2e;4e) where not null x; (1;1;2;2;4) wavg x)} each 5 cut x} each ah[1.25e][;0],'ah[1e][;0],'ah[0.5e][;0],'ah[0e][;0],'ah[-1e][;0]
/a1: a1,' flip `lsize`l!flip {(sum (5e;5e;35e;40e;10e)*x[;0];((5e;5e;35e;40e;10e)*x[;0]) wavg x[;1])} each {{(sum (1e;1e;2e;2e;4e) where not null x; (1;1;2;2;4) wavg x)} each 5 cut x} each al[1.25e][;0],'al[1e][;0],'al[0.5e][;0],'al[0e][;0],'al[-1e][;0]
/select (hsize wavg h) - lsize wavg l from a1


