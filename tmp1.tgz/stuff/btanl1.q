\P 7
\c 25 120
//Random seeding
system "S ",string `int$.z.T;

dt:`112021 ^ first `$(.Q.opt .z.x)`dt; //Default to a value if no supplied in arg
a1: get ` sv (`:.;dt;`a1);
a2: get ` sv (`:.;dt;`a2);
sym: get ` sv (`:.;dt;`sym);
nSamples: get ` sv (`:.;dt;`nSamples);
chunkSize: get ` sv (`:.;dt;`chunkSize);

//Calculate highs/lows/opens
highs5: { max each (floor (nSamples)%5) cut x} each a2;
lows5: { min each (floor (nSamples)%5) cut x} each a2;
opens: first each a2;
highs: max each a2; lows: min each a2;

//Indices in trades, for each entry in a2 - that way, we can track trade entries corresponding to an event
aIdx: {(first x;last x)} each nSamples cut raze {x#y} '[`int$exec chunked%chunkSize from a1;exec idx from a1] ;

//Store high/low indices - should follow arc sine distibution
idxs: (`hidx`lidx)! flip {[x] mu:max x;ml:min x; n:`int$(nSamples)%5; (where mu = max each n  cut x;where ml= min each n cut x)} each a2;
//Take average of multiple hits if there, and convert to integer
hidx: ceiling avg each idxs`hidx; 
nhidx:next hidx; 
lidx: ceiling avg each idxs`lidx; nlidx: next lidx;

//Calculate implied variance - mu/dev should be around 3.35 when targeting beta calculations
impvar:{[hl;n] (1%n)*xexp[avg hl%1.5958;2]}
getNoiseBeta:{[ivars] update beta:impvar%aivar from select avg hlbps, r:avg hl%dev hl, impvar:impvar[hl;nSamples],aivar:avg ivar,n:count i from rt where ivar within ivars}

t1: {(`ivar`ivar2000`hlbps`hl`h`l`c`o)!(avg xexp[x - prev x;2];(1%2000)*{first 1 _ xexp[x - prev x;2]} raze first each 2000 cut x ; {[x] 1e4*(x[0] - x[1])%x[1]}(max x;min x); (max x) - min x;max x;min x;last x;first x)} each a2;
update pc:prev c, po:prev o, ph:prev h, pl: prev l, pivar:prev ivar, aivar:impvar[;nSamples] each hl from `t1;
update paivar:prev aivar, phl:prev hl, nhl: next hl, rhl: 1000 xrank hl from `t1;
update prhl:prev rhl, nrhl:next rhl from `t1;
//update pbfrac:prev bfrac from update bfrac:bfracs from `t1;

varChunk:0.0000006;
rt: update r:hl%hl1 from select avg hl, dev hl, n:count i, avg hlbps by varChunk xbar ivar from t1;

/r1: select n wavg r, avg hl, dev hl, avg hlbps, sum n from select from rt where n > 4;
/r2: select n wavg r, avg hl, dev hl, avg hlbps, sum n from select from rt where n <= 4, not hl1=0, r < 100;

r1: select n wavg r, sum n, n wavg hlbps, avgSampleSize:avg n from (update r:hl%hl1 from select avg hl, dev hl, n:count i, avg hlbps by varChunk xbar ivar from t1 )  where r < 100;
r2: select r:avg hl%dev hl, sum n, n wavg avg hlbps, avgSampleSize:avg n from (update r:hl%hl1 from select avg hl, dev hl, n:count i, avg hlbps by varChunk xbar ivar from t1 )  where r > 100;

//Leave out r from r2 for now because it is mixture of distributions, and so polluted - ratio in r1 serves as proxy for now
show (select n wavg hlbps, sum n from r1,r2),' select r, avgSampleSize from r1;
show {100*x%sum x} count each group asc raze idxs`hidx;
show {100*x%sum x} count each group asc raze idxs`lidx;

//Check how randomized the movements are - e.g., hq and lq should be ~0.73 times cq (i.e. 2*(1 - 2/pi) - twice of half normal distribution variance), ho and lo should be about equal (needed for h in kalman filter), and half of mu
show select cq: var c - pc, mu: (avg h - l), hq: var h - ph, lq: var l - pl, hchg: avg h - ph, lchg: avg l - pl, cchg:avg c - pc, ho: avg h - o, lo:avg o - l,  n:count i from t1 where ivar within (0.0001;0.0003);

/stats:update icq:{impvar[x;1]} each hl from select avg hl, avg phl, avg nhl, avg prhl, avg nrhl, n:count i by 50 xbar rhl from t1;
/stats,:update icq:{impvar[x;1]} each hl from select avg hl, avg phl, avg nhl, avg prhl, avg nrhl, n:count i by 1 xbar rhl from t1 where rhl > 990;
update rhlbps:1000 xrank hlbps from `t1;
update nrhlbps:next rhlbps,prhlbps:prev rhlbps,nhlbps:next hlbps,phlbps:prev hlbps from `t1;
stats: select avg hlbps, avg phlbps, avg nhlbps, avg prhlbps, avg nrhlbps by 50 xbar rhlbps from t1;
stats,: select avg hlbps, avg phlbps, avg nhlbps, avg prhlbps, avg nrhlbps by 1 xbar rhlbps from t1 where rhlbps > 990;

.Q.gc[];
/select from update impvar: impvar[;nSamples] each hl from update r:hq%cq from  select from (update r:hl%hl1 from select avg hl, dev hl, hq:(1%nSamples)*var h - ph, lq: (1%nSamples)*var l - pl, cq:(var c - pc)%nSamples,  n:count i, avg hlbps by 0.001 xbar ivar from t1 ) where n > 5


////////// Notes ///////// 
// Noise beta might be dependent on ratio of chunk size to natural order book size. For example, with chunk size of 480, noise variance beta is around 2.7 avg. Reducing chunk size to 1/4th brings the noise beta down to 1.29 avg, about half.
//Volatility related hlbps might be a power of 0.742, i.e., variance bends down as xexp[n;0.742] with volume time scaling of n
/////////////////////////

// try to denoise the ratio of average hl to dev hl 
// - sort in increasing order of ivar, average once to denoise, and then compute
//select r:avg uhl%dev uhl, hq:var h - ph, cq: var c - pc,hchg: avg h - ph, lchg: avg l - pl, cchg:avg c - pc, ho: avg h - o, lo:avg o - l, avg uhl, med uhl, ivar:avg ivar, aivar: impvar[avg uhl;nSamples], beta:avg (impvar[;nSamples] each uhl)%ivar by 2500 xbar i from (select from (update uhl:2 mavg h - l  from `ivar xasc t1) where (h - l) > 0)
